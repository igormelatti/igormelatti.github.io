This code has been used to obtain the experimental results shown in the submitted paper.

In order to run an experiment on an input file F with budget B, you first have to install docker (https://www.docker.com/products/docker-desktop/) and a bash shell.

Then, in order to build the image, run the following command (in this directory):

docker build . -t fresh_label_name

Finally, you have to type the following command:

bash RUN_THIS.sh fresh_label_name F B

If you want to invoke the approximated algorithm with epsilon E, then type the following command:

bash RUN_THIS.sh fresh_label_name F B E

If you want to run an amortized execution on multiple budgets, provide such budgets without spaces, separated by : (so, e.g., 3:5:10 will using budgets 3, 5, and 10).

The input directory contains one of the file used, i.e. higgs-reply_network.edgelist.gz. Simply add other files from SNAP if you want to test the code behaviour with other inputs. Output files will always be in the same directory of F. 

Some full examples:

docker build . -t NIP
bash RUN_THIS.sh NIP input/higgs-reply_network.edgelist.gz 5:10:15
bash RUN_THIS.sh NIP input/higgs-reply_network.edgelist.gz 8 0.1
bash RUN_THIS.sh NIP input/higgs-reply_network.edgelist.gz 6
