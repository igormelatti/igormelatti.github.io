if [ $# -ne 3 -a $# -ne 4 ]
then
    echo "Input required:"
    echo "\t1) the label for the docker image to be used"
    echo "\t2) the input file"
    echo "\t3) the input budget (if you want an amortized execution, provide multiple budgets separated by : without spaces)"
    echo "Optional input: the input epsilon, if the approximated algorithm must be used"
    echo "Output files will be in the same directory of the input"
    exit
fi

docker_label=$1
input_file=$2
B=$3

test -f $input_file || { echo "File $input_file does not exist"; exit; }

if [ $# -eq 4 ]
then
    epsilon="-e $4"
    mode=12
else
    epsilon=""
    mode=5
fi

which docker > /dev/null || { echo docker is needed; exit; }

(docker images $docker_label | wc -l | awk '{exit($1 == 2)}') && { echo $docker_label seem not a valid docker label; exit; }

hmB=`echo $B | awk -F: '{print NF}'`

if [ $hmB -eq 1 ]
then
    if [ "$epsilon" ]
    then
	echo Computing approximated algorithm, output will be in $input_file.$B.$4.log, /usr/bin/time output will be in $input_file.$B.$4.time.log
	docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.$B.$4.time.log bash wrap_main.sh $epsilon $mode $input_file $B > $input_file.$B.$4.log 2>&1
    else
	echo Computing graph transformations, output will be in $input_file.$B.log, /usr/bin/time output will be in $input_file.$B.time.log
	docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.$B.time.log bash wrap_main.sh $mode $input_file $B > $input_file.$B.log 2>&1

	echo Using ILP solver without transformations, output will be in $input_file.lp.$B.log, /usr/bin/time output will be in $input_file.lp.$B.time.log
	docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.lp.$B.time.log bash wrap_glpsol.sh $input_file.lp > $input_file.lp.$B.log 2>&1

	echo Using ILP solver with transformations, output will be in $input_file.lp.reach_chain_detours.lp.$B.log, /usr/bin/time output will be in $input_file.lp.reach_chain_detours.lp.$B.time.log
	docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.lp.reach_chain_detours.lp.$B.time.log bash wrap_glpsol.sh $input_file.lp.reach_chain_detours.lp > $input_file.lp.reach_chain_detours.lp.$B.log 2>&1
    fi
else
    if [ "$epsilon" ]
    then
	echo Do not use multiple budgets with the approximated algorithm
	exit
    fi
    Bs=`echo $B | tr : " "`
    B1=`echo $Bs | awk '{print $1}'`
    echo Computing graph transformations, main output will be in $input_file.$B1.log, /usr/bin/time output will be in $input_file.$B1.time.log
    docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.$B1.time.log bash wrap_main.sh $mode $input_file $B1 > $input_file.$B1.log 2>&1

    echo Using ILP solver without transformations for budget $B1, output will be in $input_file.lp.$B1.log, /usr/bin/time output will be in $input_file.lp.$B1.time.log
    docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.lp.$B1.time.log bash wrap_glpsol.sh $input_file.lp > $input_file.lp.$B1.log 2>&1

    echo Using ILP solver with transformations for budget $B1, output will be in $input_file.lp.reach_chain_detours.lp.$B1.log, /usr/bin/time output will be in $input_file.lp.reach_chain_detours.lp.$B1.time.log
    docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.lp.reach_chain_detours.lp.$B1.time.log bash wrap_glpsol.sh $input_file.lp.reach_chain_detours.lp > $input_file.lp.reach_chain_detours.lp.$B1.log 2>&1

    for b in `echo $B | tr : "\n" | awk 'FNR > 1{print}'`
    do

	echo Using ILP solver without transformations for budget $b, output will be in $input_file.lp.$b.log, /usr/bin/time output will be in $input_file.lp.$b.time.log
	docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.lp.$b.time.log bash wrap_glpsol.sh $input_file.lp $b > $input_file.lp.$b.log 2>&1

	echo Using ILP solver with transformations for budget $b, output will be in $input_file.lp.reach_chain_detours.lp.$b.log, /usr/bin/time output will be in $input_file.lp.reach_chain_detours.lp.$b.time.log
	docker run -v $(dirname $(realpath $input_file))/:/usr/app/`dirname $input_file`/ -t $docker_label /usr/bin/time -v -o $input_file.lp.reach_chain_detours.lp.$b.time.log bash wrap_glpsol.sh $input_file.lp.reach_chain_detours.lp $b > $input_file.lp.reach_chain_detours.lp.$b.log 2>&1
    done
fi
