#include "alternating_algo.h"
#include "transformations.h" /* for print_stats */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <glpk.h>
#include <assert.h>
#include <float.h>

struct pair_orig {
  vertex_type u, v;
  double old_val;
} pair_orig;

/* #define DBG_ACTIVE 1 */
/* #define DBG_ACTIVE2 1 */
#if defined(DBG_ACTIVE) || defined(DBG_ACTIVE2)
char **only_for_dbg;
vertex_type *v_corr_glob;
#endif

static void pushGT(double **C, double **F, double *excess, vertex_type u, vertex_type v);
static void relabel(double **C, double **F, vertex_type *height, vertex_type u, unsigned long num_vertices);
static void discharge(double **C, double **F, double *excess, vertex_type *height, vertex_type *seen, vertex_type u, unsigned long num_vertices);
static void moveToFront(vertex_type i, vertex_type *A);
static double pushRelabel(double **C, double ** F, vertex_type *v_corr, vertex_type source, vertex_type sink, unsigned long num_vertices);
static void init_flow_capacities(graph *G, double ***flow, double ***capacities, vertex_type *v_corr);
static void pick_edges_from_G(network *N, unsigned B, struct pair_orig *hat_x);
static double solve_milp(glp_prob *F_out, network *N, struct pair_orig *hat_x, unsigned B);
static void add_constr1(glp_prob *F_out, unsigned long, unsigned long, double eta, double **flow, enh_edges_hashtable *from_edges_to_col);
static void add_constr2(glp_prob *F_out, struct pair_orig *hat_x, unsigned B, enh_edges_hashtable *, vertex_type *);
static glp_prob *init_F_out(network *N, unsigned B, enh_edges_hashtable **, vertex_type **);
static void restore_edges(double **C, vertex_type *v_corr, struct pair_orig *hat_x, unsigned B);
static void delete_edges(double **C, vertex_type *v_corr, struct pair_orig *hat_x, unsigned B);
static void erase(double **, unsigned long);

double alternating_algo(network *N, unsigned B, double eps){
  double eta_star = (double)-1;
  enh_edges_hashtable *from_edges_to_col;
  struct pair_orig *hat_x = (struct pair_orig *)calloc(B, sizeof(struct pair_orig));
  pick_edges_from_G(N, B, hat_x);
  vertex_type *v_corr;
  glp_prob *F_out = init_F_out(N, B, &from_edges_to_col, &v_corr);
  double **flow, **capacities, res;
  init_flow_capacities(N->G, &flow, &capacities, v_corr);
  unsigned num_iter = 1;
  char str_stat[128];
  while (1) {
    delete_edges(capacities, v_corr, hat_x, B);
    erase(flow, N->G->num_vertices);
#if defined(DBG_ACTIVE) || defined(DBG_ACTIVE2)
    only_for_dbg = N->G->orig_names;
    v_corr_glob = v_corr;
#endif
    double MF = pushRelabel(capacities, flow, v_corr, N->s, N->t, N->G->num_vertices);
    if (MF == 0) {
      glp_delete_prob(F_out);
      return 0;
    }
    restore_edges(capacities, v_corr, hat_x, B);
    if (eta_star == (double)-1 || MF < eta_star)
      eta_star = MF;
#ifdef DBG_ACTIVE2
    printf("MF: %lf\n", MF);
#endif
    add_constr1(F_out, N->G->num_vertices, N->G->num_edges, MF, flow, from_edges_to_col);
    res = solve_milp(F_out, N, hat_x, B);
    sprintf(str_stat, "after iteration %u (MF = %lf)", num_iter++, MF);
    print_stats(N->G, N, 1, str_stat);
    if (res - eta_star <= eps*eta_star) {
      glp_delete_prob(F_out);
      return eta_star;
    }
    add_constr2(F_out, hat_x, B, from_edges_to_col, v_corr);
  }
  return (double)-1;
}

#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))

static void pushGT(double **C, double **F, double *excess, vertex_type u, vertex_type v) {
  double send = excess[u] == (double)-1? C[u][v] - F[u][v] : MIN(excess[u], C[u][v] - F[u][v]);
  F[u][v] += send;
  F[v][u] -= send;
  if (excess[u] != (double)-1)
    excess[u] -= send;
  if (excess[v] != (double)-1)
    excess[v] += send;
}

static void relabel(double **C, double **F, vertex_type *height, vertex_type u, unsigned long num_vertices) {
  vertex_type v;
  vertex_type min_height = -1;
  for (v = 0; v < num_vertices; v++) {
    if (C[u][v] - F[u][v] > 0) {
      min_height = min_height == -1? height[v] : MIN(min_height, height[v]);
      height[u] = min_height + 1;
    }
  }
};

static void discharge(double **C, double **F, double *excess, vertex_type *height, vertex_type *seen, vertex_type u, unsigned long num_vertices) {
  while (excess[u] > 0) {
    if (seen[u] < num_vertices) {
      vertex_type v = seen[u];
      if ((C[u][v] - F[u][v] > 0) && (height[u] > height[v])) {
        pushGT(C, F, excess, u, v);
      } else {
        seen[u] += 1;
      }
    } else {
      relabel(C, F, height, u, num_vertices);
      seen[u] = 0;
    }
  }
}

static void moveToFront(vertex_type i, vertex_type *A) {
  vertex_type temp = A[i];
  vertex_type n;
  for (n = i; n > 0; n--) {
    A[n] = A[n-1];
  }
  A[0] = temp;
}

static double pushRelabel(double **C, double ** F, vertex_type *v_corr, vertex_type source, vertex_type sink, unsigned long num_vertices) {
  double *excess;
  vertex_type *height;
  vertex_type *list, *seen, i, p;
#ifdef DBG_ACTIVE
  unsigned long num_iter = 0;
#endif

  excess = (double *) calloc(num_vertices, sizeof(double));
  height = (vertex_type *) calloc(num_vertices, sizeof(vertex_type));
  seen = (vertex_type *) calloc(num_vertices, sizeof(vertex_type));
  list = (vertex_type *) calloc(num_vertices - 2, sizeof(vertex_type));

  for (i = 0, p = 0; i < num_vertices; i++){
    if ((i != v_corr[source]) && (i != v_corr[sink])) {
      list[p] = i;
      p++;
    }
  }

  height[v_corr[source]] = num_vertices;
  excess[v_corr[source]] = (double)-1;
  for (i = 0; i < num_vertices; i++)
    pushGT(C, F, excess, v_corr[source], i);

  p = 0;
  while (p < num_vertices - 2) {
    vertex_type u = list[p];
    vertex_type old_height = height[v_corr[u]];
    discharge(C, F, excess, height, seen, v_corr[u], num_vertices);
    if (height[v_corr[u]] > old_height) {
      moveToFront(p, list);
      p = 0;
    } else {
      p += 1;
    }
#ifdef DBG_ACTIVE
    num_iter++;
    if (num_iter%100000000 == 0)
      {
      char nattimo[128];
      sprintf(nattimo, "dbg.1.%ld.txt", num_iter);
      FILE *stream = fopen(nattimo, "w");
      for (i = 0; i < num_vertices; i++)
	for (vertex_type j = 0; j < num_vertices; j++)
	  if (F[i][j] != 0)
	    fprintf(stream, "%s %s --> %lf\n", only_for_dbg[v_corr[i]], only_for_dbg[v_corr[j]], F[i][j]);
      fclose(stream);
    }
#endif
  }

#ifdef DBG_ACTIVE
  printf("Iterations: %ld\n", num_iter);
  FILE *stream = fopen("dbg.1.txt", "w");
  for (i = 0; i < num_vertices; i++)
    for (vertex_type j = 0; j < num_vertices; j++)
      if (F[i][j] != 0)
	fprintf(stream, "%s %s --> %lf\n", only_for_dbg[v_corr[i]], only_for_dbg[v_corr[j]], F[i][j]);
  fclose(stream);
  exit(1);
#endif
  
  double maxflow = 0;
  for (i = 0; i < num_vertices; i++)
    if (F[v_corr[source]][i] > 0)
      maxflow += F[v_corr[source]][i];

  free(list);

  free(seen);
  free(height);
  free(excess);

  return maxflow;
}

static void init_flow_capacities(graph *G, double ***flow, double ***capacities, vertex_type *v_corr)
{
  vertex_type i;
  *flow = (double **) calloc(G->num_vertices, sizeof(double*));
  *capacities = (double **) calloc(G->num_vertices, sizeof(double*));
  for (i = 0; i < G->num_vertices; i++) {
    (*flow)[i] = (double *) calloc(G->num_vertices, sizeof(double));
    (*capacities)[i] = (double *) calloc(G->num_vertices, sizeof(double));
  }
  for (i = 0; i < G->max_index; i++) {
    if (G->in_deg[i] == 0 && G->out_deg[i] == 0)
      continue;
    vertex_list *tmp;
    for (tmp = G->vertices[i]; tmp; tmp = tmp->next) {
      /* if (G->in_deg[tmp->v] == 0 && G->out_deg[tmp->v] == 0) */
      /* 	continue; */ // cannot happen, at least in_deg = 1...
      (*capacities)[v_corr[i]][v_corr[tmp->v]] = tmp->cost;
    }
  }
}

static void pick_edges_from_G(network *N, unsigned B, struct pair_orig *hat_x)
{
  if (B == 0)
    return;
  vertex_type i;
  unsigned cnt = 0;
  for (i = 0; i < N->G->max_index; i++) {
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      hat_x[cnt].u = i;
      hat_x[cnt++].v = tmp->v;
      if (cnt >= B)
	return;
    }
  }
}

static double solve_milp(glp_prob *F_out, network *N, struct pair_orig *hat_x, unsigned B)
{
  vertex_type i;
  double val;
  glp_bfcp bfcp;
  glp_iocp iocp;
  glp_term_out(GLP_OFF);
  glp_get_bfcp(F_out, &bfcp);
  glp_init_iocp(&iocp);
  iocp.presolve = GLP_ON;
  glp_sort_matrix(F_out);
  glp_set_bfcp(F_out, &bfcp);
  glp_intopt(F_out, &iocp);
  assert(glp_mip_status(F_out) == GLP_OPT);
  val = glp_mip_obj_val(F_out);
  unsigned cnt = 0, cnt2 = 0;
  for (i = 0; i < N->G->max_index; i++) {
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (glp_mip_col_val(F_out, cnt + 1) > 0) {
	hat_x[cnt2].u = i;
	hat_x[cnt2++].v = tmp->v;
	if (cnt2 >= B) {
	  return val;
	}
      }
      cnt++;
    }
  }
  return val;
}

static void add_constr1(glp_prob *F_out, unsigned long num_vertices, unsigned long num_edges, double eta, double **flow, enh_edges_hashtable *from_edges_to_col)
{
  int i, j;
  unsigned long num = 0;
  for (i = 0; i < num_vertices; i++) {
    for (j = 0; j < num_vertices; j++) {
      if (flow[i][j] > 0) {
#ifdef DBG_ACTIVE2
	printf("%s %s --> %lf\n", only_for_dbg[v_corr_glob[i]], only_for_dbg[v_corr_glob[j]], flow[i][j]);
#endif
	num++;
      }
    }
  }
#ifdef DBG_ACTIVE2
  exit(1);
#endif
  int row, *ind = (int *)calloc(num + 1 + 1, sizeof(int));
  double *val = (double *)calloc(num + 1 + 1, sizeof(double));
  row = glp_add_rows(F_out, 1);
  num = 0;
  for (i = 0; i < num_vertices; i++) {
    for (j = 0; j < num_vertices; j++) {
      if (flow[i][j] > 0) {
	num++;
	ind[num] = get_element_eeh(i, j, from_edges_to_col);
#if 0
	val[num] = -flow[i][j];
#else
	char str_tmp[128];
	/* sprintf(str_tmp, "%lf", -flow[i][j]); */
	sprintf(str_tmp, "%.*g", DBL_DIG, -flow[i][j]);
	val[num] = strtod(str_tmp, (char **)0);
#endif
      }
    }
  }
  ind[num + 1] = num_edges + 1; /* variable eta */
  val[num + 1] = 1.0;
  glp_set_row_bnds(F_out, row, GLP_UP, 0, eta);
  glp_set_mat_row(F_out, row, num + 1, ind, val);
  free(ind);
  free(val);
}

static void add_constr2(glp_prob *F_out, struct pair_orig *hat_x, unsigned B, enh_edges_hashtable *from_edges_to_col, vertex_type *v_corr)
{
  int row, i;
  static int *ind = (int *)0;
  static double *val = (double *)0;
  if (!ind) {
    ind = (int *)calloc(B + 1, sizeof(int));
    val = (double *)calloc(B + 1, sizeof(double));
  }
  row = glp_add_rows(F_out, 1);
  for (i = 0; i < B; i++) {
    /* assert(is_present_eeh(hat_x[i].u, hat_x[i].v)); */
    ind[i + 1] = get_element_eeh(v_corr[hat_x[i].u], v_corr[hat_x[i].v], from_edges_to_col);
    val[i + 1] = 1.0;
  }
  glp_set_row_bnds(F_out, row, GLP_UP, 0, B - 1);
  glp_set_mat_row(F_out, row, B, ind, val);
}

static glp_prob *init_F_out(network *N, unsigned B, enh_edges_hashtable **from_edges_to_col, vertex_type **v_corr)
{
  glp_prob *ret = glp_create_prob();
  glp_add_cols(ret, N->G->num_edges + 1);
  *from_edges_to_col = init_enh_edges_hashtable(N->G->num_edges);
  vertex_type i;
  unsigned long num = 0, len_name = 30;
  char *name = (char *)calloc(len_name, sizeof(char));
  int row, *ind = (int *)calloc(N->G->num_edges + 1, sizeof(int));
  double *val = (double *)calloc(N->G->num_edges + 1, sizeof(double));
  *v_corr = (vertex_type *) calloc(N->G->max_index, sizeof(vertex_type));
  vertex_type v_corr_ind = 0;
  for (i = 0; i < N->G->max_index; i++) {
    if (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0)
      continue;
    (*v_corr)[i] = v_corr_ind++;
  }
  for (i = 0; i < N->G->max_index; i++) {
    if (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0)
      continue;
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (strlen(N->G->orig_names[i]) + strlen(N->G->orig_names[tmp->v]) + strlen("x__") + 1 > len_name) {
	len_name = strlen(N->G->orig_names[i]) + strlen(N->G->orig_names[tmp->v]) + strlen("x__") + 1;
	name = (char *)realloc(name, len_name*sizeof(char));
      }
      sprintf(name, "x_%s_%s", N->G->orig_names[i], N->G->orig_names[tmp->v]);
      glp_set_col_kind(ret, num + 1, GLP_BV);
      glp_set_col_name(ret, num + 1, name);
      glp_set_col_bnds(ret, num + 1, GLP_DB, 0, 1);
      glp_set_obj_coef(ret, num + 1, 0.0);
      add_element_eeh((*v_corr)[i], (*v_corr)[tmp->v], num + 1, *from_edges_to_col);
      ind[num + 1] = num + 1;
      val[num + 1] = 1;
      /* printf("DBG: %s -> %ld\n", name, num + 1); */
      num++;
    }
  }
  sprintf(name, "eta");
  glp_set_col_kind(ret, num + 1, GLP_CV);
  glp_set_col_name(ret, num + 1, name);
  glp_set_col_bnds(ret, num + 1, GLP_LO, 0, 0);
  glp_set_obj_coef(ret, num + 1, 1.0);
  glp_set_obj_dir(ret, GLP_MAX);
  row = glp_add_rows(ret, 1);
  glp_set_row_bnds(ret, row, GLP_FX, B, B);
  glp_set_mat_row(ret, row, num, ind, val);
  free(ind);
  free(val);
  free(name);
  return ret;
}

static void restore_edges(double **C, vertex_type *v_corr, struct pair_orig *hat_x, unsigned B)
{
  int i;
  for (i = 0; i < B; i++) 
    C[v_corr[hat_x[i].u]][v_corr[hat_x[i].v]] = hat_x[i].old_val;
}

static void delete_edges(double **C, vertex_type *v_corr, struct pair_orig *hat_x, unsigned B)
{
  int i;
  for (i = 0; i < B; i++) {
    hat_x[i].old_val = C[v_corr[hat_x[i].u]][v_corr[hat_x[i].v]];
    C[v_corr[hat_x[i].u]][v_corr[hat_x[i].v]] = 0;
  }
}

static void erase(double **flow, unsigned long num_vertices)
{
  vertex_type i;
  for (i = 0; i < num_vertices; i++) 
    bzero(flow[i], num_vertices*sizeof(double));
}
