#ifndef __ALTERNATING_ALGO_H__
#define __ALTERNATING_ALGO_H__
#include "network.h"

double alternating_algo(network *N, unsigned B, double eps);
double alternating_algo_ilp(network *N, unsigned B, double eps);

#endif
