#include "alternating_algo.h"
#include "transformations.h" /* for print_stats */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <glpk.h>
#include <assert.h>
#include <float.h>

#define THRESHOLD_FOR_0 1e-10

struct pair {
  vertex_type u, v;
  double old_val;
} pair;

#define DBG_ACTIVE 1

static void pick_edges_from_G(network *N, unsigned B, struct pair *hat_x);
static double solve_milp(glp_prob *F_out);
static void get_milp_sol(glp_prob *F_out, network *N, struct pair *hat_x, unsigned B);
static void add_constr1(glp_prob *F_out, double eta, struct pair *flow, unsigned long, enh_edges_hashtable *from_edges_to_col, unsigned long);
static void add_constr2(glp_prob *F_out, struct pair *hat_x, unsigned B, enh_edges_hashtable *from_edges_to_col);
static glp_prob *init_F_out(network *N, unsigned B, enh_edges_hashtable **);
static glp_prob *maximum_flow_ilp(network *N, enh_edges_hashtable **from_edges_to_col);
static void set_hat_x(glp_prob *P, struct pair *hat_x, unsigned, enh_edges_hashtable *from_edges_to_col, int);
static unsigned long get_milp_sol_flow(glp_prob *F_out, network *N, struct pair *flow);

double alternating_algo_ilp(network *N, unsigned B, double eps)
{
  double eta_star = (double)-1;
  enh_edges_hashtable *from_edges_to_col, *from_edges_to_col_MF;
  struct pair *hat_x = (struct pair *)calloc(B, sizeof(struct pair));
  pick_edges_from_G(N, B, hat_x);
  glp_prob *F_out = init_F_out(N, B, &from_edges_to_col);
  glp_prob *for_MF;
  for_MF = maximum_flow_ilp(N, &from_edges_to_col_MF);
  double res;
  /* enhd_edges_hashtable *flow = init_enhd_edges_hashtable(N->G->num_edges); */
  struct pair *flow = (struct pair *)calloc(N->G->num_edges, sizeof(struct pair));
  unsigned long flow_len = 0;
  unsigned num_iter = 1;
  char str_stat[128];
  while (1) {
    double MF;
    set_hat_x(for_MF, hat_x, B, from_edges_to_col_MF, 0);
    MF = solve_milp(for_MF);
    flow_len = get_milp_sol_flow(for_MF, N, flow);
    set_hat_x(for_MF, hat_x, B, from_edges_to_col_MF, 1);
    if (MF == 0) {
      glp_delete_prob(F_out);
      free(hat_x);
      free(flow);
      return 0;
    }
    if (eta_star == (double)-1 || MF < eta_star)
      eta_star = MF;
    add_constr1(F_out, MF, flow, flow_len, from_edges_to_col, N->G->num_edges);
    res = solve_milp(F_out);
    get_milp_sol(F_out, N, hat_x, B);
    sprintf(str_stat, "after iteration %u (MF = %lf)", num_iter++, MF);
    print_stats(N->G, N, 1, str_stat);
    if (res - eta_star <= eps*eta_star) {
      glp_delete_prob(F_out);
      free(hat_x);
      free(flow);
      return eta_star;
    }
    add_constr2(F_out, hat_x, B, from_edges_to_col);
  }
  free(hat_x);
  free(flow);
  return (double)-1;
}


static void pick_edges_from_G(network *N, unsigned B, struct pair *hat_x)
{
  if (B == 0)
    return;
  vertex_type i;
  unsigned cnt = 0;
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (tmp->v == N->s)
	continue;
      hat_x[cnt].u = i;
      hat_x[cnt++].v = tmp->v;
      if (cnt >= B)
	return;
    }
  }
}

static double solve_milp(glp_prob *F_out)
{
  vertex_type i;
  double val;
  glp_bfcp bfcp;
  glp_iocp iocp;
  glp_term_out(GLP_OFF);
  glp_get_bfcp(F_out, &bfcp);
  glp_init_iocp(&iocp);
  iocp.presolve = GLP_ON;
  glp_sort_matrix(F_out);
  glp_set_bfcp(F_out, &bfcp);
  glp_intopt(F_out, &iocp);
  assert(glp_mip_status(F_out) == GLP_OPT);
  return glp_mip_obj_val(F_out);
}

static void get_milp_sol(glp_prob *F_out, network *N, struct pair *hat_x, unsigned B)
{
  unsigned cnt = 0, cnt2 = 0;
  vertex_type i;
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (tmp->v == N->s)
	continue;
      if (glp_mip_col_val(F_out, cnt + 1) > THRESHOLD_FOR_0) {
	hat_x[cnt2].u = i;
	hat_x[cnt2++].v = tmp->v;
	if (cnt2 >= B) 
	  return;
      }
      cnt++;
    }
  }
}

static void add_constr1(glp_prob *F_out, double eta, struct pair *flow, unsigned long flow_len, enh_edges_hashtable *from_edges_to_col, unsigned long num_edges)
{
  int row, *ind = (int *)calloc(flow_len + 1 + 1, sizeof(int));
  double *val = (double *)calloc(flow_len + 1 + 1, sizeof(double));
  row = glp_add_rows(F_out, 1);
  unsigned long i;
  for (i = 0; i < flow_len; i++) {
    ind[i + 1] = get_element_eeh(flow[i].u, flow[i].v, from_edges_to_col);
    char str_tmp[128];
    /* sprintf(str_tmp, "%lf", -i->val); */
    sprintf(str_tmp, "%.*g", DBL_DIG, -flow[i].old_val);
    val[i + 1] = strtod(str_tmp, (char **)0);
  }
  ind[i + 1] = num_edges + 1; /* variable eta */
  val[i + 1] = 1.0;
  glp_set_row_bnds(F_out, row, GLP_UP, 0, eta);
  glp_set_mat_row(F_out, row, flow_len + 1, ind, val);
  free(ind);
  free(val);
}

static void add_constr2(glp_prob *F_out, struct pair *hat_x, unsigned B, enh_edges_hashtable *from_edges_to_col)
{
  int row;
  static int *ind = (int *)0;
  static double *val = (double *)0;
  if (!ind) {
    ind = (int *)calloc(B + 1, sizeof(int));
    val = (double *)calloc(B + 1, sizeof(double));
  }
  row = glp_add_rows(F_out, 1);
  unsigned i;
  for (i = 0; i < B; i++) {
    ind[i + 1] = get_element_eeh(hat_x[i].u, hat_x[i].v, from_edges_to_col);
    val[i + 1] = 1.0;
  }
  glp_set_row_bnds(F_out, row, GLP_UP, 0, B - 1);
  glp_set_mat_row(F_out, row, B, ind, val);
}

static glp_prob *init_F_out(network *N, unsigned B, enh_edges_hashtable **from_edges_to_col)
{
  glp_prob *ret = glp_create_prob();
  glp_add_cols(ret, N->G->num_edges + 1);
  *from_edges_to_col = init_enh_edges_hashtable(N->G->num_edges);
  vertex_type i;
  unsigned long num = 0, num2;
#ifdef DBG_ACTIVE
  unsigned long len_name = 30;
  char *name = (char *)calloc(len_name, sizeof(char));
#endif
  int row, *ind = (int *)calloc(N->G->num_edges + 1, sizeof(int));
  double *val = (double *)calloc(N->G->num_edges + 1, sizeof(double));
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (tmp->v == N->s)
	continue;
#ifdef DBG_ACTIVE
      if (strlen(N->G->orig_names[i]) + strlen(N->G->orig_names[tmp->v]) + strlen("x__") + 1 > len_name) {
	len_name = strlen(N->G->orig_names[i]) + strlen(N->G->orig_names[tmp->v]) + strlen("x__") + 1;
	name = (char *)realloc(name, len_name*sizeof(char));
      }
      sprintf(name, "x_%s_%s", N->G->orig_names[i], N->G->orig_names[tmp->v]);
      glp_set_col_name(ret, num + 1, name);
#endif
      glp_set_col_kind(ret, num + 1, GLP_BV);
      glp_set_col_bnds(ret, num + 1, GLP_DB, 0, 1);
      glp_set_obj_coef(ret, num + 1, 0.0);
      add_element_eeh(i, tmp->v, num + 1, *from_edges_to_col);
      ind[num + 1] = num + 1;
      val[num + 1] = 1;
      /* printf("DBG: %s -> %ld\n", name, num + 1); */
      num++;
    }
  }
  num2 = num;
  for (; num < N->G->num_edges; num++) {
    glp_set_col_kind(ret, num + 1, GLP_CV);
    glp_set_col_bnds(ret, num + 1, GLP_FX, 0, 0);
    glp_set_obj_coef(ret, num + 1, 0);
  }
  glp_set_col_kind(ret, num + 1, GLP_CV);
#ifdef DBG_ACTIVE
  sprintf(name, "eta");
  glp_set_col_name(ret, num + 1, name);
  free(name);
#endif
  glp_set_col_bnds(ret, num + 1, GLP_LO, 0, 0);
  glp_set_obj_coef(ret, num + 1, 1.0);
  glp_set_obj_dir(ret, GLP_MAX);
  row = glp_add_rows(ret, 1);
  glp_set_row_bnds(ret, row, GLP_FX, B, B);
  glp_set_mat_row(ret, row, num2, ind, val);
  free(ind);
  free(val);
  return ret;
}

static glp_prob *maximum_flow_ilp(network *N, enh_edges_hashtable **from_edges_to_col)
{
  static glp_prob *ret = (glp_prob *)0;
  ret = glp_create_prob();
  glp_set_obj_dir(ret, GLP_MAX);
  glp_add_cols(ret, N->G->num_edges);
  vertex_type i;
  unsigned long num = 0;
#ifdef DBG_ACTIVE
  int len_name = 30;
  char *name = (char *)calloc(len_name, sizeof(char));
#endif
  vertex_list *tmp;
  *from_edges_to_col = init_enh_edges_hashtable(N->G->num_edges);
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (tmp->v == N->s)
	continue;
#ifdef DBG_ACTIVE
      if (strlen(N->G->orig_names[i]) + strlen(N->G->orig_names[tmp->v]) + strlen("y__") + 1 > len_name) {
	len_name = strlen(N->G->orig_names[i]) + strlen(N->G->orig_names[tmp->v]) + strlen("y__") + 1;
	name = (char *)realloc(name, len_name*sizeof(char));
      }
      sprintf(name, "p_%s_%s", N->G->orig_names[i], N->G->orig_names[tmp->v]);
      glp_set_col_name(ret, num + 1, name);
#endif
      glp_set_col_kind(ret, num + 1, GLP_CV);
      if (tmp->cost > 0)
	glp_set_col_bnds(ret, num + 1, GLP_DB, 0, tmp->cost);
      else
	glp_set_col_bnds(ret, num + 1, GLP_FX, 0, 0);
      glp_set_obj_coef(ret, num + 1, i == N->s? 1 : 0);
      add_element_eeh(i, tmp->v, num + 1, *from_edges_to_col);
      num++;
    }
  }
#ifdef DBG_ACTIVE
  free(name);
#endif
  for (; num < N->G->num_edges; num++) {
    glp_set_col_kind(ret, num + 1, GLP_CV);
    glp_set_col_bnds(ret, num + 1, GLP_FX, 0, 0);
    glp_set_obj_coef(ret, num + 1, 0);
  }
  /* one constraint exiting-from-s == entering in t */
  int row, col = 0, *ind = (int *)calloc(N->G->max_outdeg + N->G->max_indeg + 1, sizeof(int));
  double *val = (double *)calloc(N->G->max_outdeg + N->G->max_indeg + 1, sizeof(double));
  num = 0;
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (tmp->v == N->s)
	continue;
      if (i == N->s && tmp->v == N->t) {
	num++;
	continue;
      }
      if (i == N->s) {
	ind[col + 1] = num + 1;
	val[col + 1] = 1.0;
	col++;
      }
      if (tmp->v == N->t) {
	ind[col + 1] = num + 1;
	val[col + 1] = -1.0;
	col++;
      }
      num++;
    }
  }
  assert(col > 0);
  row = glp_add_rows(ret, 1);
  glp_set_row_bnds(ret, row, GLP_FX, 0, 0);
  glp_set_mat_row(ret, row, col, ind, val);
  /* then this, modified as in the algorithm */
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || i == N->s || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    vertex_type j;
    num = col = 0;
    for (j = 0; j < N->G->max_index; j++) {
      if (j == N->t || (N->G->in_deg[j] == 0 && N->G->out_deg[j] == 0))
	continue;
      /* if (j == i) */
      /* 	continue; */
      for (tmp = N->G->vertices[j]; tmp; tmp = tmp->next) {
	if (tmp->v == N->s)
	  continue;
	if (i == j) {
	  ind[col + 1] = num + 1;
	  val[col + 1] = 1.0;
	  col++;
	}
	if (i == tmp->v) {
	  ind[col + 1] = num + 1;
	  val[col + 1] = -1.0;
	  col++;
	}
	num++;
      }
    }
    if (col > 0) {
      row = glp_add_rows(ret, 1);
      glp_set_row_bnds(ret, row, GLP_FX, 0, 0);
      glp_set_mat_row(ret, row, col, ind, val);
    }
  }
  free(ind);
  free(val);
  return ret;
}

static unsigned long get_milp_sol_flow(glp_prob *F_out, network *N, struct pair *flow)
{
  unsigned cnt = 0, cnt2 = 0;
  vertex_type i;
  unsigned long num = 0;
  for (i = 0; i < N->G->max_index; i++) {
    if (i == N->t || (N->G->in_deg[i] == 0 && N->G->out_deg[i] == 0))
      continue;
    vertex_list *tmp;
    for (tmp = N->G->vertices[i]; tmp; tmp = tmp->next) {
      if (tmp->v == N->s)
	continue;
      double tmpval = glp_mip_col_val(F_out, cnt + 1);
      if (tmpval > THRESHOLD_FOR_0) {
	flow[num].u = i;
	flow[num].v = tmp->v;
	flow[num++].old_val = tmpval;
      }
      cnt++;
    }
  }
  return num;
}

static void set_hat_x(glp_prob *P, struct pair *hat_x, unsigned B, enh_edges_hashtable *from_edges_to_col, int normal_val)
{
  unsigned i;
  for (i = 0; i < B; i++) {
    if (!normal_val)
      hat_x[i].old_val = glp_get_col_ub(P, get_element_eeh(hat_x[i].u, hat_x[i].v, from_edges_to_col));
    glp_set_col_bnds(P, get_element_eeh(hat_x[i].u, hat_x[i].v, from_edges_to_col), (!normal_val || hat_x[i].old_val == 0)? GLP_FX : GLP_DB, 0, !normal_val? 0 : hat_x[i].old_val);
  }
}
