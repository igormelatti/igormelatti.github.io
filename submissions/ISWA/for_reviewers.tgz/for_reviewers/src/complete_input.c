#include "graph.h"
#include <assert.h>
#include "network.h"
#include "complete_input.h"
#include "transformations.h"
#include "hash_table.h"

#define MULT_FOR_COSTS 1.0

void add_costs(graph *G, int directed)
{
  const double mult = MULT_FOR_COSTS;
  unsigned long i;
  for (i = 0; i < G->num_vertices; i++) {
    vertex_list *tmp;
    for (tmp = G->vertices[i]; tmp; tmp = tmp-> next) {
      if (directed)
	tmp->cost = mult*((G->in_deg[i] + G->out_deg[i]) + (G->in_deg[tmp->v] + G->out_deg[tmp->v]))/(G->max_indeg + G->max_outdeg);
      else
	tmp->cost = mult*((G->in_deg[i]) + (G->in_deg[tmp->v]))/G->max_indeg;
    }
  }
}

void add_st(network *N)
{
  simple_hashtable *nodes_ok;
  int dummy, max = -1;
  nodes_list *i = (nodes_list *)0;
  N->s = N->G->argmax_outdeg;
  N->t = N->G->argmax_indeg;
  nodes_ok = reachable_nodes_chains(N->G, N->s, (vertex_type *)0, 0, 0);
  assert(how_many(nodes_ok) > 1); /* it is the maximum outdegree... */
  if (N->s == N->t || !is_present(N->t, nodes_ok)) {
    for (i = iter_ht(nodes_ok, i, &dummy); i; i = iter_ht(nodes_ok, i, &dummy)) {
      if (i->index != N->s && !exists_edge(N->s, i->index, N->G) && (max == -1 || N->G->in_deg[i->index] > max)) {
	max = N->G->in_deg[i->index];
	N->t = i->index;
      }
    }
  }
  free_simple_hashtable(nodes_ok);
  /* return (simple_hashtable *)0; /\* better to recompute *\/ */
}
