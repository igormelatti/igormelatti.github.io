#ifndef __COMPLETE_INPUT_H__
#define __COMPLETE_INPUT_H__

void add_costs(graph *G, int directed);
void add_st(network *N);

#endif
