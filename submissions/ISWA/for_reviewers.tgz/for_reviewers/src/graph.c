#include "graph.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
/* #include <stdio.h> */

#define HT_DIMENSION (1 << 20)

graph *init_graph(int also_ht)
{
  graph *ret = (graph *)calloc(1, sizeof(graph));
  if (!ret)
    return ret;
  ret->vertices = (vertex_list **)calloc(VERTEX_BLOCKS, sizeof(vertex_list *));
  ret->orig_names = (char **)calloc(VERTEX_BLOCKS, sizeof(char *));
  ret->in_deg = (unsigned long *)calloc(VERTEX_BLOCKS, sizeof(unsigned long));
  ret->out_deg = (unsigned long *)calloc(VERTEX_BLOCKS, sizeof(unsigned long));
  if (!ret->vertices || !ret->orig_names || !ret->in_deg || !ret->out_deg)
    return (graph *)0;
  ret->num_vertices_alloc = VERTEX_BLOCKS;
  if (also_ht)
    ret->vertices_to_ind = init_hashtable(HT_DIMENSION);
  return ret;
}

/* still used by inverted_graph; n is a valid vertex number, to be used as it is */
int add_node(vertex_type n, graph *G)
{
  if (n >= G->num_vertices_alloc){
    /* not enough allocated nodes to store n: allocate enough blocks for n */
    unsigned long hm = n/VERTEX_BLOCKS + 1;
    G->vertices = (vertex_list **)realloc(G->vertices, hm*VERTEX_BLOCKS*sizeof(vertex_list *));
    G->orig_names = (char **)realloc(G->orig_names, hm*VERTEX_BLOCKS*sizeof(char *));
    G->in_deg = (unsigned long *)realloc(G->in_deg, hm*VERTEX_BLOCKS*sizeof(unsigned long));
    G->out_deg = (unsigned long *)realloc(G->out_deg, hm*VERTEX_BLOCKS*sizeof(unsigned long));
    if (!G->vertices || !G->orig_names || !G->in_deg || !G->out_deg)
      return 1;
    /* the newly allocated memory is zeroed */
    memset(&G->vertices[G->num_vertices_alloc], 0, sizeof(vertex_list *)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    memset(&G->orig_names[G->num_vertices_alloc], 0, sizeof(char *)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    memset(&G->in_deg[G->num_vertices_alloc], 0, sizeof(unsigned long)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    memset(&G->out_deg[G->num_vertices_alloc], 0, sizeof(unsigned long)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    G->num_vertices_alloc = hm*VERTEX_BLOCKS;
  }
  if (G->max_index < n + 1) 
    G->max_index = n + 1;
  G->num_vertices++;
  return 0;
}

int add_node_str(const char *name, graph *G, vertex_type *n)
{
  long tmp;
  char c;
  if (!G->vertices_to_ind)
    return 2;
  tmp = add_name(name, G->vertices_to_ind, &c);
  if (tmp >= 0)
    *n = (vertex_type)tmp; /* either a newly added, or the already present one (c == 1 in this latter case */
  else /* only if not enough virtual memory... */
    return 3;
  if (*n >= G->num_vertices_alloc){
    unsigned long hm = (*n)/VERTEX_BLOCKS + 1;
    G->vertices = (vertex_list **)realloc(G->vertices, hm*VERTEX_BLOCKS*sizeof(vertex_list *));
    G->orig_names = (char **)realloc(G->orig_names, hm*VERTEX_BLOCKS*sizeof(char *));
    G->in_deg = (unsigned long *)realloc(G->in_deg, hm*VERTEX_BLOCKS*sizeof(unsigned long));
    G->out_deg = (unsigned long *)realloc(G->out_deg, hm*VERTEX_BLOCKS*sizeof(unsigned long));
    if (!G->vertices || !G->orig_names || !G->in_deg || !G->out_deg)
      return 1;
    memset(&G->vertices[G->num_vertices_alloc], 0, sizeof(vertex_list *)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    memset(&G->orig_names[G->num_vertices_alloc], 0, sizeof(vertex_list *)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    memset(&G->in_deg[G->num_vertices_alloc], 0, sizeof(unsigned long)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    memset(&G->out_deg[G->num_vertices_alloc], 0, sizeof(unsigned long)*(hm*VERTEX_BLOCKS - G->num_vertices_alloc));
    G->num_vertices_alloc = hm*VERTEX_BLOCKS;
  }
  if (G->max_index < *n + 1)
    G->max_index = *n + 1;
  if (!c) {
    G->num_vertices++;
    G->orig_names[*n] = strdup(name);
  }
  return 0;
}

int add_edge(vertex_type n1, vertex_type n2, graph *G)
{
  vertex_list *p;
  if (n1 >= G->max_index || n2 >= G->max_index)
    return 1;
  if (exists_edge(n1, n2, G)) /* if it is a multigraph, just consider the first edge */
    return 0; /* 3; */
  p = (vertex_list *)calloc(1, sizeof(vertex_list));
  if (!p)
    return 2;
  p->v = n2;
  p->cost = 0.0;
  p->next = G->vertices[n1];
  G->vertices[n1] = p;
  G->num_edges++;
  G->out_deg[n1]++;
  G->in_deg[n2]++;
  if (G->max_indeg < G->in_deg[n2]) {
    G->max_indeg = G->in_deg[n2];
    G->argmax_indeg = n2;
  }
  if (G->max_outdeg < G->out_deg[n1]) {
    G->max_outdeg = G->out_deg[n1];
    G->argmax_outdeg = n1;
  }
  return 0;
}

int add_edge_cost(vertex_type n1, vertex_type n2, double c, graph *G)
{
  vertex_list *p;
  if (n1 >= G->max_index || n2 >= G->max_index)
    return 1;
  if (exists_edge(n1, n2, G)) /* if it is a multigraph, just consider the first edge */
    return 0; /* 3; */
  p = (vertex_list *)calloc(1, sizeof(vertex_list));
  if (!p)
    return 2;
  p->v = n2;
  p->cost = c;
  p->next = G->vertices[n1];
  G->vertices[n1] = p;
  G->num_edges++;
  G->out_deg[n1]++;
  G->in_deg[n2]++;
  if (G->max_indeg < G->in_deg[n2]) {
    G->max_indeg = G->in_deg[n2];
    G->argmax_indeg = n2;
  }
  if (G->max_outdeg < G->out_deg[n1]) {
    G->max_outdeg = G->out_deg[n1];
    G->argmax_outdeg = n1;
  }
  G->with_costs = 1;
  return 0;
}

vertex_type str_to_type(const char *str)
{
  return (unsigned long)atol(str);
}

void free_graph(graph *G)
{
  if (G->vertices) {
    unsigned i;

    for (i = 0; i < G->max_index; i++) {
      vertex_list *tmp = G->vertices[i];
      while (tmp) {
	vertex_list *tmp2 = G->vertices[i];
	G->vertices[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
      free(G->orig_names[i]);
    }
    free(G->vertices);
    free(G->in_deg);
    free(G->out_deg);
    free(G->orig_names);
  }
  if (G->vertices_to_ind)
    free_hashtable(G->vertices_to_ind);
  free(G);
}

/* only_out: if 1, only erase outgoing edges, ingoing ones are left; otherwise, both ingoing and outgoing are deleted and the node is isolated */
void erase_vertex(graph *G, vertex_type tbd, int only_out)
{
  vertex_list *tmp;
  unsigned long i;
  if (G->in_deg[tbd] == 0 && G->out_deg[tbd] == 0) { /* if already isolated, do not delete it */
    assert(!G->vertices[tbd]);
    return;
  }
  if (!only_out)
    G->num_vertices--;
  tmp = G->vertices[tbd];
  while (tmp) {
    vertex_list *tmp2 = tmp;
    G->in_deg[tmp->v]--;
    if (G->in_deg[tmp->v] == 0 && G->out_deg[tmp->v] == 0) {
      assert(!G->vertices[tmp->v]);
      G->num_vertices--;
    }
    tmp = tmp->next;
    free(tmp2);
    G->num_edges--;
  }
  G->vertices[tbd] = (vertex_list *)0;
  G->out_deg[tbd] = 0;
  if (only_out)
    return;
  for (i = 0; i < G->max_index; i++) {
    vertex_list *vl;
    tmp = vl = G->vertices[i];
    while (vl) {
      if (vl->v == tbd) {
	G->in_deg[tbd]--;
	G->out_deg[i]--;
	if (G->in_deg[i] == 0 && G->out_deg[i] == 0)
	  G->num_vertices--;
	G->num_edges--;
	if (tmp == vl) { /* it is the first in the list */
	  G->vertices[i] = G->vertices[i]->next;
	  free(tmp);
	}
	else {
	  /*

	    1 3 5 7
	    delete 5
	    tmp-> 3, vl-> 5
	    1 3 7
	    ok
	    
	   */
	  tmp->next = vl->next;
	  free(vl);
	}
	break;
      }
      else {
	tmp = vl;
	vl = vl->next;
      }
    }
  }
  assert(G->in_deg[tbd] == 0);
}

/* assumption: only called on vertices which are on a chain, in_deg edge already deleted */
void simple_erase_vertex(graph *G, vertex_type tbd)
{
  G->in_deg[G->vertices[tbd]->v]--; /* necessary for the last one of the chain */
  free(G->vertices[tbd]);
  G->vertices[tbd] = (vertex_list *)0;
  G->out_deg[tbd] = 0;
  G->num_vertices--;
  G->num_edges--;
}


/* this is indeed the number of nodes having out degree > 0, not really useful (sink node may not be counted...) */
unsigned long used_vertices(graph *G)
{
  unsigned long i, ret = 0;
  for (i = 0; i < G->max_index; i++) {
    if (G->vertices[i]) 
      ret++;
  }
  return ret;
}

vertex_list *exists_edge(vertex_type n1, vertex_type n2, graph *G)
{
  vertex_list *p;
  if (n1 >= G->max_index || n2 >= G->max_index)
    return (vertex_list *)0;
  for (p = G->vertices[n1]; p; p = p->next) {
    if (p->v == n2)
      return p;
  }
  return p;
}

vertex_list *exists_edge_upd_cost(vertex_type n1, vertex_type n2, double c, graph *G)
{
  vertex_list *p;
  if (n1 >= G->max_index || n2 >= G->max_index)
    return (vertex_list *)0;
  for (p = G->vertices[n1]; p; p = p->next) {
    if (p->v == n2) {
      p->cost += c;
      /* if (p->cost > c) */
      /* 	p->cost = c; */
      return p;
    }
  }
  return p;
}

void recompute_maxdeg(graph *G)
{
  unsigned long i;
  G->max_indeg = 0;
  G->max_outdeg = 0;
  for (i = 0; i < G->max_index; i++) {
    if (G->out_deg[i] > G->max_outdeg) {
      G->max_outdeg = G->out_deg[i];
      G->argmax_outdeg = i;
    }
    if (G->in_deg[i] > G->max_indeg) {
      G->max_indeg = G->in_deg[i];
      G->argmax_indeg = i;
    }
  }
}

#include <stdio.h>
#include <errno.h>

int dump_graph(graph *G, const char *filename)
{
  unsigned i;
  FILE *stream;

  if (!G->vertices)
    return -1;

  stream = fopen(filename, "w");
  if (!stream) {
    printf("Impossible to open %s because of %s\n", filename, strerror(errno));
    return -1;
  }
  
  for (i = 0; i < G->max_index; i++) {
    vertex_list *tmp = G->vertices[i];
    while (tmp) {
      fprintf(stream, "%s %s %lf\n", G->orig_names[i], G->orig_names[tmp->v], G->with_costs? tmp->cost : (double)0);
      tmp = tmp->next;
    }
  }
  fclose(stream);
  return 0;
}

#define CLOSE_AND_FAIL { free_graph(ret); return (graph *)0; }

graph *inverted_graph(graph *G)
{
  graph *ret = init_graph(0);
  unsigned long i;
  for (i = 0; i < G->max_index; i++) 
    if (add_node(i, ret)) CLOSE_AND_FAIL;
  for (i = 0; i < G->max_index; i++) {
    vertex_list *tmp = G->vertices[i];
    while (tmp) {
      if (add_edge_cost(tmp->v, i, tmp->cost, ret)) CLOSE_AND_FAIL;
      tmp = tmp->next;
    }
  }
  return ret;
}

void simple_erase_edge(graph *G, vertex_type t1, vertex_type t2)
{
  vertex_list *tmp = G->vertices[t1], *prev = (vertex_list *)0;
  while (tmp) {
    if (tmp->v == t2) {
      if (prev == (vertex_list *)0)
	G->vertices[t1] = G->vertices[t1]->next;
      else
	prev->next = tmp->next;
      free(tmp);
      G->out_deg[t1]--;
      G->in_deg[t2]--;
      G->num_edges--;
      return;
    }
    prev = tmp;
    tmp = tmp->next;
  }
}

vertex_type ind_from_name(graph *G, char *name)
{
  unsigned long *ret = get_ht_index(name, G->vertices_to_ind);
  return *ret;
}

void check_stats(graph *G)
{
  unsigned long i, cnt_v = 0, cnt_e = 0;
  vertex_list *vl;
  for (i = 0; i < G->max_index; i++) {
    if (G->vertices[i] || G->in_deg[i] > 0)
      cnt_v++;
    for (vl = G->vertices[i]; vl; vl = vl->next)
      cnt_e++;
  }
  if (G->num_vertices != cnt_v)
    printf("num_vertices from stats: %lu\nnum_vertices from counting: %lu\n", G->num_vertices, cnt_v);
  if (G->num_edges != cnt_e)
    printf("num_edges from stats: %lu\nnum_edges from counting: %lu\n", G->num_edges, cnt_e);
}

void check_in_degs(graph *G)
{
  unsigned long i;
  unsigned long *in_deg = (unsigned long *)calloc(G->max_index, sizeof(unsigned long));
  unsigned long *out_deg = (unsigned long *)calloc(G->max_index, sizeof(unsigned long));
  vertex_list *vl;
  for (i = 0; i < G->max_index; i++) {
    for (vl = G->vertices[i]; vl; vl = vl->next) {
      in_deg[vl->v]++;
      out_deg[i]++;
    }
  }
  for (i = 0; i < G->max_index; i++) {
    if (in_deg[i] != G->in_deg[i])
      printf("%lu (node %s): going in from stats: %lu\ngoing in from counting: %lu\n", i, G->orig_names[i], G->in_deg[i], in_deg[i]);
    if (out_deg[i] != G->out_deg[i])
      printf("%lu (node %s): going out from stats: %lu\ngooutg out from counting: %lu\n", i, G->orig_names[i], G->out_deg[i], out_deg[i]);
  }
  free(in_deg);
  free(out_deg);
}
