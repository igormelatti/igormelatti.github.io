#ifndef __GRAPH_H__
#define __GRAPH_H__
#define VERTEX_BLOCKS 1024

#include "hash_table.h"

typedef unsigned long vertex_type;

typedef struct vertex_list {
  vertex_type v;
  double cost;
  struct vertex_list *next;
} vertex_list;

/* always directed graphs (if undirected, the reverse edge is added for each edge) */
/* isolated nodes: out_deg == in_deg == 0. They are not counted by general_read; thus they are stripped out in reading phase. Thus, if a node has out_deg == in_deg == 0 it has been deleted (assuming general_read was used; otherwise, it could be a non-existing node). */

typedef struct graph {
  vertex_list **vertices; /* vertices[i] is the list of adj nodes of i, possibly with cost */
  unsigned long *in_deg, *out_deg;
  unsigned long num_vertices, num_vertices_alloc, max_index, num_edges, max_indeg, max_outdeg;
  vertex_type argmax_indeg, argmax_outdeg;
  hashtable *vertices_to_ind;
  char with_costs;
  char **orig_names; /* orig_names[i] contains the original (input) name for i */
} graph;

graph *init_graph(int also_ht);
int add_node(vertex_type n, graph *G);
int add_node_str(const char *n, graph *G, vertex_type *);
int add_edge(vertex_type n1, vertex_type n2, graph *G);
int add_edge_cost(vertex_type n1, vertex_type n2, double c, graph *G);
vertex_type str_to_type(const char *);
void free_graph(graph *G);
unsigned long used_vertices(graph *G);
void erase_vertex(graph *G, vertex_type i, int);
void recompute_maxdeg(graph *G);
vertex_list *exists_edge(vertex_type n1, vertex_type n2, graph *G);
int dump_graph(graph *G, const char *filename);
graph *inverted_graph(graph *);
void simple_erase_vertex(graph *G, vertex_type tbd);
void simple_erase_edge(graph *G, vertex_type, vertex_type);
vertex_type ind_from_name(graph *G, char *);
vertex_list *exists_edge_upd_cost(vertex_type n1, vertex_type n2, double c, graph *G);
void check_stats(graph *G);
#endif
