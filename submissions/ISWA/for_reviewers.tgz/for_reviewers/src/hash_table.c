#include "hash_table.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

hashtable *init_hashtable(unsigned long dimension)
{
  hashtable *ret = (hashtable *)calloc(1, sizeof(hashtable));
  if (!ret)
    return ret;
  ret->nl = (names_list **)calloc(dimension, sizeof(names_list *));
  if (!ret->nl)
    return (hashtable *)0;
  ret->slots_allocated = dimension;
  return ret;
}

static unsigned int PJWHash(const char* str, unsigned int length)
{
   const unsigned int BitsInUnsignedInt = (unsigned int)(sizeof(unsigned int) * 8);
   const unsigned int ThreeQuarters     = (unsigned int)((BitsInUnsignedInt  * 3) / 4);
   const unsigned int OneEighth         = (unsigned int)(BitsInUnsignedInt / 8);
   const unsigned int HighBits          =
                      (unsigned int)(0xFFFFFFFF) << (BitsInUnsignedInt - OneEighth);
   unsigned int hash = 0;
   unsigned int test = 0;
   unsigned int i    = 0;

   for (i = 0; i < length; str, ++i)
   {
      hash = (hash << OneEighth) + (*str);

      if ((test = hash & HighBits) != 0)
      {
         hash = (( hash ^ (test >> ThreeQuarters)) & (~HighBits));
      }
   }
   return hash;
}

static unsigned int PJWHash_eehd(unsigned long n1, unsigned long n2)
{
   return n1 + n2;
}

long add_name(const char *n, hashtable *H, char *already_pres)
{
  unsigned long *pres = get_ht_index(n, H);
  if (!pres) {
    unsigned int hash = PJWHash(n, strlen(n))%H->slots_allocated;
    names_list *p = (names_list *)calloc(1, sizeof(names_list));
    if (!p)
      return -1;
    *already_pres = 0;
    p->v = strdup(n);
    p->index = H->num_names_stored;
    p->next = H->nl[hash];
    H->nl[hash] = p;
    H->num_names_stored++;
    return (long)(H->num_names_stored - 1);
  }
  else {
    *already_pres = 1;
    return (long)(*pres);
  }
}

int remove_name(const char *n, hashtable *H)
{
  unsigned int hash = PJWHash(n, strlen(n))%H->slots_allocated;
  names_list *nl, *prev;
  for (nl = H->nl[hash], prev = nl; nl; prev = nl, nl = nl->next) {
    if (strcmp(nl->v, n) == 0) {
      if (prev == nl) {
	H->nl[hash] = H->nl[hash]->next;
	free(prev);
      }
      else {
	prev->next = nl->next;
	free(nl);
      }
      H->num_names_stored--;
      return 1;
    }
  }
  return 0;
}

unsigned long *get_ht_index(const char *n, hashtable *H)
{
  unsigned int hash = PJWHash(n, strlen(n))%H->slots_allocated;
  names_list *nl;
  for (nl = H->nl[hash]; nl; nl = nl->next) {
    if (strcmp(nl->v, n) == 0)
      return &nl->index;
  }
  return (unsigned long*)0;
}

names_list *get_ht_entry(const char *n, hashtable *H)
{
  unsigned int hash = PJWHash(n, strlen(n))%H->slots_allocated;
  names_list *nl;
  for (nl = H->nl[hash]; nl; nl = nl->next) {
    if (strcmp(nl->v, n) == 0)
      return nl;
  }
  return (names_list *)0;
}

void free_hashtable(hashtable *H)
{
  if (H->nl) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      names_list *tmp = H->nl[i];
      while (tmp) {
	names_list *tmp2 = H->nl[i];
	free(H->nl[i]->v);
	H->nl[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
    }
    free(H->nl);
  }
  free(H);
}

simple_hashtable *init_simple_hashtable(unsigned long dimension)
{
  simple_hashtable *ret = (simple_hashtable *)calloc(1, sizeof(simple_hashtable));
  if (!ret)
    return ret;
  ret->nl = (nodes_list **)calloc(dimension, sizeof(nodes_list *));
  if (!ret->nl)
    return (simple_hashtable *)0;
  ret->slots_allocated = dimension;
  return ret;
}

int is_present(unsigned long n, simple_hashtable *H)
{
  unsigned int hash = PJWHash((char*)&n, sizeof(unsigned long))%H->slots_allocated;
  nodes_list *nl;
  for (nl = H->nl[hash]; nl; nl = nl->next) {
    if (nl->index == n)
      return 1;
  }
  return 0;
}

int add_element(unsigned long n, simple_hashtable *H)
{
  if (!is_present(n, H)) {
    unsigned int hash = PJWHash((char*)&n, sizeof(unsigned long))%H->slots_allocated;
    nodes_list *p = (nodes_list *)calloc(1, sizeof(nodes_list));
    if (!p)
      return -1;
    p->index = n;
    p->next = H->nl[hash];
    H->nl[hash] = p;
    H->num_stored++;
    return 0;
  }
  else
    return 1;
}

int remove_element(unsigned long n, simple_hashtable *H)
{
  unsigned int hash = PJWHash((char*)&n, sizeof(unsigned long))%H->slots_allocated;
  nodes_list *nl, *prev;
  for (nl = H->nl[hash], prev = nl; nl; prev = nl, nl = nl->next) {
    if (nl->index == n) {
      if (prev == nl) {
	H->nl[hash] = H->nl[hash]->next;
	free(prev);
      }
      else {
	prev->next = nl->next;
	free(nl);
      }
      H->num_stored--;
      return 1;
    }
  }
  return 0;
}

nodes_list *iter_ht(simple_hashtable *H, nodes_list *prev, int *idonthavetime)
{
  if (prev == (nodes_list *)0) {
    for ((*idonthavetime) = 0; (*idonthavetime) < H->slots_allocated && !H->nl[(*idonthavetime)]; (*idonthavetime)++);
    return H->nl[(*idonthavetime)];
  }
  if (prev->next)
    return prev->next;
  for ((*idonthavetime)++; (*idonthavetime) < H->slots_allocated && !H->nl[(*idonthavetime)]; (*idonthavetime)++);
  return (*idonthavetime) < H->slots_allocated && H->nl[(*idonthavetime)]? H->nl[(*idonthavetime)] : (nodes_list *)0;
}

void free_simple_hashtable(simple_hashtable *H)
{
  if (H->nl) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      nodes_list *tmp = H->nl[i];
      while (tmp) {
	nodes_list *tmp2 = H->nl[i];
	H->nl[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
    }
    free(H->nl);
  }
  free(H);
}

void print_all(simple_hashtable *H, char **orig_names)
{
  if (H->nl) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      nodes_list *tmp = H->nl[i];
      while (tmp) {
	printf("%s\n", orig_names[tmp->index]);
	tmp = tmp->next;
      }
    }
  }
}

unsigned how_many(simple_hashtable *H)
{
  return H->num_stored;
}

void merge_simple_hashtables(simple_hashtable *H1, simple_hashtable *H2)
{
  if (H2->nl) {
    unsigned i;

    for (i = 0; i < H2->slots_allocated; i++) {
      nodes_list *tmp = H2->nl[i];
      while (tmp) {
	add_element(tmp->index, H1);
	tmp = tmp->next;
      }
    }
  }
}

edges_hashtable *init_edges_hashtable(unsigned long dimension)
{
  edges_hashtable *ret = (edges_hashtable *)calloc(1, sizeof(edges_hashtable));
  if (!ret)
    return ret;
  ret->el = (edges_list **)calloc(dimension, sizeof(edges_list *));
  if (!ret->el)
    return (edges_hashtable *)0;
  ret->slots_allocated = dimension;
  return ret;
}

int is_present_eh(unsigned long n1, unsigned long n2, edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  edges_list *nl;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2)
      return 1;
  }
  return 0;
}

int add_element_eh(unsigned long n1, unsigned long n2, edges_hashtable *H)
{
  if (!is_present_eh(n1, n2, H)) {
    static char *for_hash = (char *)0;
    unsigned int hash;
    edges_list *nl;
    if (!for_hash)
      for_hash = (char *)calloc(2, sizeof(unsigned long));
    memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
    memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
    hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
    edges_list *p = (edges_list *)calloc(1, sizeof(edges_list));
    if (!p)
      return -1;
    p->v1 = n1;
    p->v2 = n2;
    p->next = H->el[hash];
    H->el[hash] = p;
    H->num_stored++;
    return 0;
  }
  else
    return 1;
}

void free_edges_hashtable(edges_hashtable *H)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      edges_list *tmp = H->el[i];
      while (tmp) {
	edges_list *tmp2 = H->el[i];
	H->el[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
    }
    free(H->el);
  }
  free(H);
}

void remove_all_edges_hashtable(edges_hashtable *H)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      edges_list *tmp = H->el[i];
      while (tmp) {
	edges_list *tmp2 = H->el[i];
	H->el[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
      H->el[i] = (edges_list *)0;
    }
  }
}

void print_all_eh(edges_hashtable *H, char **orig_names)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      edges_list *tmp = H->el[i];
      while (tmp) {
	printf("%s %s\n", orig_names[tmp->v1], orig_names[tmp->v2]);
	tmp = tmp->next;
      }
    }
  }
}

edges_list *iter_ht_eh(edges_hashtable *H, edges_list *prev, int *idonthavetime)
{
  if (prev == (edges_list *)0) {
    for ((*idonthavetime) = 0; (*idonthavetime) < H->slots_allocated && !H->el[(*idonthavetime)]; (*idonthavetime)++);
    return H->el[(*idonthavetime)];
  }
  if (prev->next)
    return prev->next;
  for ((*idonthavetime)++; (*idonthavetime) < H->slots_allocated && !H->el[(*idonthavetime)]; (*idonthavetime)++);
  return (*idonthavetime) < H->slots_allocated && H->el[(*idonthavetime)]? H->el[(*idonthavetime)] : (edges_list *)0;
}

unsigned how_many_eh(edges_hashtable *H)
{
  return H->num_stored;
}

int remove_element_eh(unsigned long n1, unsigned long n2, edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  edges_list *nl, *prev;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash], prev = nl; nl; prev = nl, nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      if (prev == nl) {
	H->el[hash] = H->el[hash]->next;
	free(prev);
      }
      else {
	prev->next = nl->next;
	free(nl);
      }
      H->num_stored--;
      return 1;
    }
  }
  return 0;
}

enh_edges_hashtable *init_enh_edges_hashtable(unsigned long dimension)
{
  enh_edges_hashtable *ret = (enh_edges_hashtable *)calloc(1, sizeof(enh_edges_hashtable));
  if (!ret)
    return ret;
  ret->el = (enh_edges_list **)calloc(dimension, sizeof(enh_edges_list *));
  if (!ret->el)
    return (enh_edges_hashtable *)0;
  ret->slots_allocated = dimension;
  return ret;
}

int is_present_eeh(unsigned long n1, unsigned long n2, enh_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enh_edges_list *nl;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2)
      return 1;
  }
  return 0;
}

int get_element_eeh(unsigned long n1, unsigned long n2, enh_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enh_edges_list *nl;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2)
      return nl->val;
  }
  return -1;
}

int add_element_eeh(unsigned long n1, unsigned long n2, int value, enh_edges_hashtable *H)
{
  if (!is_present_eeh(n1, n2, H)) {
    static char *for_hash = (char *)0;
    unsigned int hash;
    enh_edges_list *nl;
    if (!for_hash)
      for_hash = (char *)calloc(2, sizeof(unsigned long));
    memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
    memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
    hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
    enh_edges_list *p = (enh_edges_list *)calloc(1, sizeof(enh_edges_list));
    if (!p)
      return -1;
    p->v1 = n1;
    p->v2 = n2;
    p->val = value;
    p->next = H->el[hash];
    H->el[hash] = p;
    H->num_stored++;
    return 0;
  }
  else
    return 1;
}

void free_enh_edges_hashtable(enh_edges_hashtable *H)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      enh_edges_list *tmp = H->el[i];
      while (tmp) {
	enh_edges_list *tmp2 = H->el[i];
	H->el[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
    }
    free(H->el);
  }
  free(H);
}

void print_all_eeh(enh_edges_hashtable *H, char **orig_names)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      enh_edges_list *tmp = H->el[i];
      while (tmp) {
	printf("%s %s --> %d\n", orig_names[tmp->v1], orig_names[tmp->v2], tmp->val);
	tmp = tmp->next;
      }
    }
  }
}

enh_edges_list *iter_ht_eeh(enh_edges_hashtable *H, enh_edges_list *prev, int *idonthavetime)
{
  if (prev == (enh_edges_list *)0) {
    for ((*idonthavetime) = 0; (*idonthavetime) < H->slots_allocated && !H->el[(*idonthavetime)]; (*idonthavetime)++);
    return H->el[(*idonthavetime)];
  }
  if (prev->next)
    return prev->next;
  for ((*idonthavetime)++; (*idonthavetime) < H->slots_allocated && !H->el[(*idonthavetime)]; (*idonthavetime)++);
  return (*idonthavetime) < H->slots_allocated && H->el[(*idonthavetime)]? H->el[(*idonthavetime)] : (enh_edges_list *)0;
}

unsigned how_many_eeh(enh_edges_hashtable *H)
{
  return H->num_stored;
}

int remove_element_eeh(unsigned long n1, unsigned long n2, enh_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enh_edges_list *nl, *prev;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash], prev = nl; nl; prev = nl, nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      if (prev == nl) {
	H->el[hash] = H->el[hash]->next;
	free(prev);
      }
      else {
	prev->next = nl->next;
	free(nl);
      }
      H->num_stored--;
      return 1;
    }
  }
  return 0;
}

enhd_edges_hashtable *init_enhd_edges_hashtable(unsigned long dimension)
{
  enhd_edges_hashtable *ret = (enhd_edges_hashtable *)calloc(1, sizeof(enhd_edges_hashtable));
  if (!ret)
    return ret;
  ret->el = (enhd_edges_list **)calloc(dimension, sizeof(enhd_edges_list *));
  if (!ret->el)
    return (enhd_edges_hashtable *)0;
  ret->slots_allocated = dimension;
  return ret;
}

#if 1
int is_present_eehd(unsigned long n1, unsigned long n2, enhd_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2)
      return 1;
  }
  return 0;
}

double *get_element_eehd(unsigned long n1, unsigned long n2, enhd_edges_hashtable *H)
{
  double *ret = (double *)0;
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      ret = &(nl->val);
    }
  }
  return ret;
}

int update_element_eehd(unsigned long n1, unsigned long n2, double val, enhd_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      nl->val = val;
      return 0;
    }
  }
  return 1;
}

int add_element_eehd(unsigned long n1, unsigned long n2, double value, enhd_edges_hashtable *H)
{
  if (!is_present_eehd(n1, n2, H)) {
    static char *for_hash = (char *)0;
    unsigned int hash;
    enhd_edges_list *nl;
    if (!for_hash)
      for_hash = (char *)calloc(2, sizeof(unsigned long));
    memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
    memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
    hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
    enhd_edges_list *p = (enhd_edges_list *)calloc(1, sizeof(enhd_edges_list));
    if (!p)
      return -1;
    p->v1 = n1;
    p->v2 = n2;
    p->val = value;
    p->next = H->el[hash];
    H->el[hash] = p;
    H->num_stored++;
    return 0;
  }
  else
    return 1;
}

#else
int is_present_eehd(unsigned long n1, unsigned long n2, enhd_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl;
  hash = PJWHash_eehd(n1, n2)%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2)
      return 1;
  }
  return 0;
}

double *get_element_eehd(unsigned long n1, unsigned long n2, enhd_edges_hashtable *H)
{
  double *ret = (double *)0;
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl;
  hash = PJWHash_eehd(n1, n2)%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      ret = &(nl->val);
    }
  }
  return ret;
}

int update_element_eehd(unsigned long n1, unsigned long n2, double val, enhd_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl;
  hash = PJWHash_eehd(n1, n2)%H->slots_allocated;
  for (nl = H->el[hash]; nl; nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      nl->val = val;
      return 0;
    }
  }
  return 1;
}

int add_element_eehd(unsigned long n1, unsigned long n2, double value, enhd_edges_hashtable *H)
{
  if (!is_present_eehd(n1, n2, H)) {
    static char *for_hash = (char *)0;
    unsigned int hash;
    enhd_edges_list *nl;
    hash = PJWHash_eehd(n1, n2)%H->slots_allocated;
    enhd_edges_list *p = (enhd_edges_list *)calloc(1, sizeof(enhd_edges_list));
    if (!p)
      return -1;
    p->v1 = n1;
    p->v2 = n2;
    p->val = value;
    p->next = H->el[hash];
    H->el[hash] = p;
    H->num_stored++;
    return 0;
  }
  else
    return 1;
}
#endif

void free_enhd_edges_hashtable(enhd_edges_hashtable *H)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      enhd_edges_list *tmp = H->el[i];
      while (tmp) {
	enhd_edges_list *tmp2 = H->el[i];
	H->el[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
    }
    free(H->el);
  }
  free(H);
}

void remove_all_enhd_edges_hashtable(enhd_edges_hashtable *H)
{
  if (H->el) {
    unsigned i;

    for (i = 0; i < H->slots_allocated; i++) {
      enhd_edges_list *tmp = H->el[i];
      while (tmp) {
	enhd_edges_list *tmp2 = H->el[i];
	H->el[i] = tmp->next;
	tmp = tmp->next;
	free(tmp2);
      }
      H->el[i] = (enhd_edges_list *)0;
    }
  }
}

void print_all_eehd(enhd_edges_hashtable *H, char **orig_names, char *filename)
{
  if (H->el) {
    unsigned i;
    FILE *stream;

    if (filename)
      stream = fopen(filename, "w");
    
    for (i = 0; i < H->slots_allocated; i++) {
      enhd_edges_list *tmp = H->el[i];
      while (tmp) {
	fprintf(filename? stream : stdout, "%s %s --> %lf\n", orig_names[tmp->v1], orig_names[tmp->v2], tmp->val);
	tmp = tmp->next;
      }
    }
    if (filename)
      fclose(stream);
  }
}

enhd_edges_list *iter_ht_eehd(enhd_edges_hashtable *H, enhd_edges_list *prev, int *idonthavetime)
{
  if (prev == (enhd_edges_list *)0) {
    for ((*idonthavetime) = 0; (*idonthavetime) < H->slots_allocated && !H->el[(*idonthavetime)]; (*idonthavetime)++);
    return H->el[(*idonthavetime)];
  }
  if (prev->next)
    return prev->next;
  for ((*idonthavetime)++; (*idonthavetime) < H->slots_allocated && !H->el[(*idonthavetime)]; (*idonthavetime)++);
  return (*idonthavetime) < H->slots_allocated && H->el[(*idonthavetime)]? H->el[(*idonthavetime)] : (enhd_edges_list *)0;
}

unsigned how_many_eehd(enhd_edges_hashtable *H)
{
  return H->num_stored;
}

int remove_element_eehd(unsigned long n1, unsigned long n2, enhd_edges_hashtable *H)
{
  static char *for_hash = (char *)0;
  unsigned int hash;
  enhd_edges_list *nl, *prev;
  if (!for_hash)
    for_hash = (char *)calloc(2, sizeof(unsigned long));
  memcpy((void *)for_hash, (void *)&n1, sizeof(unsigned long));
  memcpy((void *)&for_hash[1], (void *)&n2, sizeof(unsigned long));
  hash = PJWHash(for_hash, 2*sizeof(unsigned long))%H->slots_allocated;
  for (nl = H->el[hash], prev = nl; nl; prev = nl, nl = nl->next) {
    if (nl->v1 == n1 && nl->v2 == n2) {
      if (prev == nl) {
	H->el[hash] = H->el[hash]->next;
	free(prev);
      }
      else {
	prev->next = nl->next;
	free(nl);
      }
      H->num_stored--;
      return 1;
    }
  }
  return 0;
}

