#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__
typedef struct names_list {
  char *v;
  unsigned long index;
  struct names_list *next;
} names_list;

typedef struct hashtable {
  names_list **nl;
  unsigned long slots_allocated;
  unsigned long num_names_stored;
} hashtable;

typedef struct nodes_list {
  unsigned long index;
  struct nodes_list *next;
} nodes_list;

typedef struct simple_hashtable {
  nodes_list **nl;
  unsigned long slots_allocated;
  unsigned long num_stored;
} simple_hashtable;

typedef struct edges_list {
  unsigned long v1, v2;
  struct edges_list *next;
} edges_list;

typedef struct edges_hashtable {
  edges_list **el;
  unsigned long slots_allocated;
  unsigned long num_stored;
} edges_hashtable;

typedef struct enh_edges_list {
  unsigned long v1, v2;
  int val;
  struct enh_edges_list *next;
} enh_edges_list;

typedef struct enh_edges_hashtable {
  enh_edges_list **el;
  unsigned long slots_allocated;
  unsigned long num_stored;
} enh_edges_hashtable;

typedef struct enhd_edges_list {
  unsigned long v1, v2;
  double val;
  struct enhd_edges_list *next;
} enhd_edges_list;

typedef struct enhd_edges_hashtable {
  enhd_edges_list **el;
  unsigned long slots_allocated;
  unsigned long num_stored;
} enhd_edges_hashtable;

hashtable *init_hashtable(unsigned long num_slots);
long add_name(const char *n, hashtable *H, char *already);
int remove_name(const char *n, hashtable *H);
void free_hashtable(hashtable *H);
unsigned long *get_ht_index(const char *n, hashtable *H);
names_list *get_ht_entry(const char *n, hashtable *H);

simple_hashtable *init_simple_hashtable(unsigned long num_slots);
int add_element(unsigned long n, simple_hashtable *H);
int is_present(unsigned long n, simple_hashtable *H);
void free_simple_hashtable(simple_hashtable *H);
void print_all(simple_hashtable *H, char **orig_names);
unsigned how_many(simple_hashtable *H);
nodes_list *iter_ht(simple_hashtable *H, nodes_list *prev, int *idonthavetime);
int remove_element(unsigned long n, simple_hashtable *H);
void merge_simple_hashtables(simple_hashtable *H1, simple_hashtable *H2);

edges_hashtable *init_edges_hashtable(unsigned long num_slots);
int add_element_eh(unsigned long n1, unsigned long n2, edges_hashtable *H);
int is_present_eh(unsigned long n, unsigned long n2, edges_hashtable *H);
void remove_all_edges_hashtable(edges_hashtable *H);
void free_edges_hashtable(edges_hashtable *H);
void print_all_eh(edges_hashtable *H, char **orig_names);
unsigned how_many_eh(edges_hashtable *H);
edges_list *iter_ht_eh(edges_hashtable *H, edges_list *prev, int *idonthavetime);
int remove_element_eh(unsigned long n, unsigned long n2, edges_hashtable *H);

enh_edges_hashtable *init_enh_edges_hashtable(unsigned long num_slots);
int add_element_eeh(unsigned long n1, unsigned long n2, int , enh_edges_hashtable *H);
int get_element_eeh(unsigned long n1, unsigned long n2, enh_edges_hashtable *H);
int is_present_eeh(unsigned long n, unsigned long n2, enh_edges_hashtable *H);
void free_enh_edges_hashtable(enh_edges_hashtable *H);
void print_all_eeh(enh_edges_hashtable *H, char **orig_names);
unsigned how_many_eeh(enh_edges_hashtable *H);
enh_edges_list *iter_ht_eeh(enh_edges_hashtable *H, enh_edges_list *prev, int *idonthavetime);
int remove_element_eeh(unsigned long n, unsigned long n2, enh_edges_hashtable *H);

enhd_edges_hashtable *init_enhd_edges_hashtable(unsigned long num_slots);
int add_element_eehd(unsigned long n1, unsigned long n2, double , enhd_edges_hashtable *H);
int update_element_eehd(unsigned long n1, unsigned long n2, double , enhd_edges_hashtable *H);
double *get_element_eehd(unsigned long n1, unsigned long n2, enhd_edges_hashtable *H);
int is_present_eehd(unsigned long n, unsigned long n2, enhd_edges_hashtable *H);
void remove_all_enhd_edges_hashtable(enhd_edges_hashtable *H);
void free_enhd_edges_hashtable(enhd_edges_hashtable *H);
void print_all_eehd(enhd_edges_hashtable *H, char **orig_names, char *);
unsigned how_many_eehd(enhd_edges_hashtable *H);
enhd_edges_list *iter_ht_eehd(enhd_edges_hashtable *H, enhd_edges_list *prev, int *idonthavetime);
int remove_element_eehd(unsigned long n, unsigned long n2, enhd_edges_hashtable *H);
#endif
