#include "read_input.h"
#include "graph.h"
#include "milp.h"
#include "network.h"
#include "complete_input.h"
#include "transformations.h"
#include "alternating_algo.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

static void usage(char *name)
{
  fprintf(stderr, "Usage: %s [-i] [-s source] [-t target] [-l file_lp] [-e epsilon] mode namefile budget\n\n\n\tmode = 5 performs all transformations, creating two MILPs: one with no reductions (file_lp) and one (file_lp.reach_chain_detours.lp) with all reductions\n\tmode = 6 computes GMF with approximation algo, using pushRelabel for maximum flow computations (requires epsilon)\n\tmode = 12 computes GMF with approximation algo, using ILP for maximum flow computations (requires epsilon)\n\tif -i is given, then edge costs in input file are ignored when present (recall that the approach does not work with edges having a negative cost)\n\tif source and target are not given, the node with greater out-degree is the source, and the reachable node with greater in-degree is the destination\n\tdefault for file_lp is filename + \".lp\"\n\n\n", name);
}

static int check_opt(int mode, double eps, char *source, char *target, int budget)
{
  if (mode != 5 && mode != 6 && mode != 12) {
    fprintf(stderr, "mode %d is unavailable\n", mode);
    return 1;
  }
  if (mode >= 6 && eps == (double)-1) {
    fprintf(stderr, "eps required for mode %d\n", mode);
    return 1;
  }
  if ((source && !target) || (!source && target)) {
    fprintf(stderr, "source and target must be either both provided or none\n");
    return 1;
  }
  if (budget < 0) {
    fprintf(stderr, "budget cannot be negative, it is %d\n", budget);
    return 1;
  }
  if (budget == 0 && mode >= 6 && mode <= 17) {
    fprintf(stderr, "budget cannot be zero with the approximated algorithm\n");
    return 1;
  }
  return 0;
}

int main(int argc, char **argv)
{
  graph *G;
  network *N;
  int directed, mode, ret;
  printf("Version %s launched as", CURR_VERSION_VULN);
  for (directed = 1; directed < argc; directed++)
    printf(" %s", argv[directed]);
  printf("\n\n");
  opterr = 0;
  directed = 1;
  int ignore = 0, budget;
  char *source = (char *)0, *target = (char *)0, *file_lp = (char *)0, *filename;
  double eps = (double)-1;
  while ((ret = getopt(argc, argv, "s:t:e:l:i")) != -1) {
    switch (ret) {
    case 's':
      source = optarg;
      break;
    case 't':
      target = optarg;
      break;
    case 'e':
      eps = atof(optarg);
      break;
    case 'l':
      file_lp = optarg;
      break;
    case 'i':
      ignore = 1;
      break;
    default:
      usage(argv[0]);
      return(1);
    }
  }
  if (optind + 3 != argc) {
    fprintf(stderr, "Missing mode, filename, budget\n");
    usage(argv[0]);
    return 3;
  }
  mode = atoi(argv[optind]);
  filename = argv[optind + 1];
  budget = atoi(argv[optind + 2]);
  if (check_opt(mode, eps, source, target, budget)) {
    usage(argv[0]);
    return(2);
  }
  G = general_read(filename, directed, ignore);
  if (G) 
    print_stats(G, (network *)0, directed, "after reading from file");
  else
    return 2;
  if (!G->with_costs) {
    add_costs(G, directed);
    print_stats(G, (network *)0, directed, "after adding costs");
  }
  N = init_network(G, 0, 0);
  if (!source)
    add_st(N);
  else {
    N->s = ind_from_name(G, source);
    N->t = ind_from_name(G, target);
  }
  if (mode <= 0 || mode > 14) {
    free_network(N);
    return 0;
  }
  print_stats(G, N, directed, "before starting main computation");
  if (mode >= 1 && mode <= 5 && !file_lp) {
    file_lp = (char *)calloc(strlen(filename) + strlen(".lp") + 1, sizeof(char));
    sprintf(file_lp, "%s.lp", filename);
  }
  if (mode == 5) {
    char *name = (char *)calloc(strlen(file_lp) + strlen(".reach_chain_detours.lp") + 1, sizeof(char));
    create_milp(N, (unsigned)budget, file_lp);
    print_stats(G, N, directed, "after creating milp without reductions");
    reachable_and_chains(N, directed);
    print_stats(G, N, directed, "after reachability and chains reduction");
    detours_elimination(N, directed);
    print_stats(G, N, directed, "after detours elimination");
    sprintf(name, "%s.reach_chain_detours.lp", file_lp);
    create_milp(N, (unsigned)budget, name);
    print_stats(G, N, directed, "after creating milp with detours elimination (all transformations)");
    free(name);
  }
  else {
    double res;
    if (mode == 6)
      res = alternating_algo(N, (unsigned)budget, eps);
    else 
      res = alternating_algo_ilp(N, (unsigned)budget, eps);
    printf("GMF with %sapproximated algo is %lf\n", mode == 6? "" : "memory efficient ", res);
    print_stats(G, N, directed, "after executing the approximated algorithm");
  }
  free_network(N);
  return 0;
}
