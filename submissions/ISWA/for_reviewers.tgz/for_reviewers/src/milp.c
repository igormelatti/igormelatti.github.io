#include "milp.h"
#include "network.h"
#include "graph.h"
#include "hash_table.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

int create_milp(network *N, unsigned B, const char *filename)
{
  if (N->G->num_vertices == 0)
    return 2;
  FILE *stream = fopen(filename, "w");
  vertex_list *vl;
  unsigned long i, count = 2;
  if (!stream)
    return 1;
  fprintf(stream, "Minimize\n  obj:");
  for (i = 0; i < N->G->max_index; i++) {
    for (vl = N->G->vertices[i]; vl; vl = vl->next)
      fprintf(stream, " %+lf y_%s_%s", vl->cost, N->G->orig_names[i], N->G->orig_names[vl->v]);
  }
  fprintf(stream, "\nSubject To\n  c_1:");
  for (i = 0; i < N->G->max_index; i++) {
    for (vl = N->G->vertices[i]; vl; vl = vl->next)
      fprintf(stream, " +z_%s_%s", N->G->orig_names[i], N->G->orig_names[vl->v]);
  }
  fprintf(stream, " <= %u\n", B);
  for (i = 0; i < N->G->max_index; i++) {
    for (vl = N->G->vertices[i]; vl; vl = vl->next)
      fprintf(stream, "  c_%lu: y_%s_%s + z_%s_%s - d_%s + d_%s >= 0\n", count++, N->G->orig_names[i], N->G->orig_names[vl->v], N->G->orig_names[i], N->G->orig_names[vl->v], N->G->orig_names[vl->v], N->G->orig_names[i]);
  }
  fprintf(stream, "  c_%lu: d_%s = 0\n  c_%lu: d_%s = 1\n", count++, N->G->orig_names[N->s], count++, N->G->orig_names[N->t]);
  fprintf(stream, "Binary\n");
  for (i = 0; i < N->G->max_index; i++) {
    if (N->G->vertices[i] || N->G->in_deg[i] > 0)
      fprintf(stream, "  d_%s\n", N->G->orig_names[i]);
    for (vl = N->G->vertices[i]; vl; vl = vl->next)
      fprintf(stream, "  y_%s_%s\n  z_%s_%s\n", N->G->orig_names[i], N->G->orig_names[vl->v], N->G->orig_names[i], N->G->orig_names[vl->v]);
  }
  fprintf(stream, "End\n");
  fclose(stream);
  return 0;
}
