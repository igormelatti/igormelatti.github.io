#ifndef __MILP_H__
#define __MILP_H__

#include "network.h"

int create_milp(network *N, unsigned B, const char *filename);
void solve_milp(const char *filename);
void extract_res(const char *filename);

#endif
