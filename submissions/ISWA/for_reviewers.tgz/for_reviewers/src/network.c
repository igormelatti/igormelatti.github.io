#include "network.h"
#include <stdlib.h>

network *init_network(graph *G, vertex_type s, vertex_type t)
{
  network *ret = (network *)calloc(1, sizeof(network));
  if (!ret)
    return ret;
  ret->G = G;
  ret->s = s;
  ret->t = t;
  return ret;
}

void free_network(network *N)
{
  if (N->G)
    free_graph(N->G);
  free(N);
}

network *inverted_network(network *N)
{
  return init_network(inverted_graph(N->G), N->t, N->s);
}
