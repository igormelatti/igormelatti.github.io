#ifndef __NETWORK_H__
#define __NETWORK_H__

#include "graph.h"

typedef struct network {
  graph *G;
  vertex_type s, t;
} network;

network *init_network(graph *, vertex_type s, vertex_type t);
void free_network(network *N);
network *inverted_network(network *);
#endif
