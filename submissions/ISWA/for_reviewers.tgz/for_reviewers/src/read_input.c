#include "read_input.h"
#include "graph.h"
#include "hash_table.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

#define BLOCK_READ (1 << 20)

#if 1
#define CLOSE_ALL { free_graph(ret); gzclose(stream); return (graph *)0; }
#else
#define CLOSE_ALL { free_graph(ret); fclose(stream); return (graph *)0; }
#endif
static void replace_char(char *s, char c1, char c2);
static void replace_if_needed(char *s);

#if 0
graph *easy_read(const char *filepath, int directed)
{
  graph *ret = init_graph(1);
  FILE *stream;
  size_t readb;
  char block[BLOCK_READ] = {0}, *save_block;
  unsigned offset = 0;
  if (!ret)
    return ret;
  stream = fopen(filepath, "r");
  if (!stream) {
    fprintf(stderr, "Error opening %s", filepath);
    perror("");
    return (graph *)0;
  }
  while (readb = fread(block + offset, sizeof(char), BLOCK_READ - offset - 1, stream)) {
    char *save[2];
    char *tmp, *pred;
    vertex_type n1, n2;
    if (readb == BLOCK_READ - offset - 1 && block[BLOCK_READ - 2] != '\n') {
      save_block = strrchr(block, '\n') + 1;
      offset = block + offset + readb - save_block;
      *(save_block - 1) = '\0';
    }
    else if (readb < BLOCK_READ - offset - 1) {
      block[offset + readb - 1] = '\0';
      offset = 0;
    }
    else
      offset = 0;
    tmp = strtok_r(block, "\n", &save[0]);
    for (; tmp; pred = tmp, tmp = strtok_r((char *)0, "\n", &save[0])) {
      char *tmp2;
      if (tmp[0] == '#') 
	continue;
      tmp2 = strtok_r(tmp, " \t ", &save[1]);
      n1 = str_to_type(tmp2);
      if (add_node(n1, ret)) CLOSE_ALL;
      tmp2 = strtok_r((char *)0, " \t ", &save[1]);
      n2 = str_to_type(tmp2);
      if (add_node(n2, ret)) CLOSE_ALL;
      if (add_edge(n1, n2, ret)) CLOSE_ALL;
      if (!directed) {
	if (add_edge(n2, n1, ret)) CLOSE_ALL;
      }
    }
    if (offset)
      strncpy(block, save_block, offset);
  }
  fclose(stream);
  return ret;
}
#endif

/* assumption: lines beginning with a character different from a decimal digit or a lower case letter are discarded; first two columns define edges, third column defines costs, other columns are ignored; any space or a comma is ok for separating columns */
graph *general_read(const char *filepath, int directed, int ignore_cost)
{
  graph *ret = init_graph(1);
#if 1
  gzFile stream;
#else
  FILE *stream;
#endif
  size_t readb;
  char block[BLOCK_READ] = {0}, *save_block;
  unsigned offset = 0;
  if (!ret)
    return ret;
#if 1
  stream = gzopen(filepath, "r");
#else
  stream = fopen(filepath, "r");
#endif
  if (!stream) {
    fprintf(stderr, "Error opening %s", filepath);
    perror("");
    return (graph *)0;
  }
#if 1
  while (readb = gzfread (block + offset, sizeof(char), BLOCK_READ - offset - 1, stream)) {
#else
  while (readb = fread(block + offset, sizeof(char), BLOCK_READ - offset - 1, stream)) {
#endif
    char *save[2];
    char *tmp, *pred;
    vertex_type n1, n2;
    if (readb == BLOCK_READ - offset - 1 && block[BLOCK_READ - 2] != '\n') {
      save_block = strrchr(block, '\n') + 1;
      offset = block + offset + readb - save_block;
      *(save_block - 1) = '\0';
    }
    else if (readb < BLOCK_READ - offset - 1) {
      block[offset + readb - 1] = '\0';
      offset = 0;
    }
    else
      offset = 0;
    tmp = strtok_r(block, "\n", &save[0]);
    for (; tmp; pred = tmp, tmp = strtok_r((char *)0, "\n", &save[0])) {
      char *tmp2[2];
      /* if (!isdigit(tmp[0])) */
      if (tmp[0] == '#' || isspace(tmp[0]) || (tmp[0] >= 'A' && tmp[0] <= 'Z'))
	continue;
      tmp2[0] = strtok_r(tmp, " \t, ", &save[1]);
      tmp2[1] = strtok_r((char *)0, " \t, ", &save[1]);
      if (!tmp2[1])
	continue;
      if (strlen(tmp2[1]) >= 1 && tmp2[1][strlen(tmp2[1]) - 1] == '\r')
	tmp2[1][strlen(tmp2[1]) - 1] = '\0';
      replace_if_needed(tmp2[0]);
      replace_if_needed(tmp2[1]);
      if (add_node_str(tmp2[0], ret, &n1)) CLOSE_ALL;
      if (add_node_str(tmp2[1], ret, &n2)) CLOSE_ALL;
      if (n1 == n2)
	continue; /* self loops are ignored, as they will not traverse any cut */
      if (!ignore_cost)
	tmp2[0] = strtok_r((char *)0, " \t, ", &save[1]);
      if (ignore_cost || !tmp2[0]) {
	if (add_edge(n1, n2, ret)) CLOSE_ALL;
      }
      else {
	if (add_edge_cost(n1, n2, atof(tmp2[0]), ret)) CLOSE_ALL;
      }
      if (!directed) {
	if (add_edge(n2, n1, ret)) CLOSE_ALL;
      }
    }
    if (offset)
      strncpy(block, save_block, offset);
  }
#if 1
  gzclose(stream);
#else
  fclose(stream);
#endif
  return ret;
}

static void replace_char(char *s, char c1, char c2)
{
  unsigned i;
  for (i = 0; i < strlen(s); i++) {
    if (s[i] == c1)
      s[i] = c2;
  }
}

static void replace_if_needed(char *s)
{
  if (strchr(s, ':') != (char *)0) {
    printf("Warning: node %s", s);
    replace_char(s, ':', '_');
    printf(" replaced with %s\n", s);
  }
}
