#ifndef __READ_INPUT_H__
#define __READ_INPUT_H__
#include "graph.h"

#if 0
graph *easy_read(const char *filepath, int directed);
#endif
graph *general_read(const char *filepath, int directed, int ignore_cost);
#endif
