#include "stack.h"
#include "hash_table.h"
#include <stdlib.h>
#include <stdio.h>

#define STACK_DIM (1 << 15)

stack *init_stack()
{
  stack *ret = (stack *)calloc(1, sizeof(stack));
  if (!ret)
    return ret;
  ret->lifo = (pair *)calloc(STACK_DIM, sizeof(pair));
  if (!ret->lifo) {
    free(ret);
    return (stack *)0;
  }
  ret->alloc = STACK_DIM;
  return ret;
}

pair top(stack *S)
{
  return S->lifo[S->depth - 1];
}

void update_top(stack *S)
{
  /* S->lifo[S->depth - 1].d++; */
  if (S->lifo[S->depth - 1].next)
    S->lifo[S->depth - 1].next = S->lifo[S->depth - 1].next->next;
}

/* void update_top_rev(stack *S) */
/* { */
/*   S->lifo[S->depth - 1].d--; */
/* } */

void pop(stack *S)
{
  S->depth--;
}

int push(stack *S, vertex_type v, vertex_list *first)
{
  /* S->lifo[S->depth].d = 0; */
  S->lifo[S->depth].next = first;
  S->lifo[S->depth].s = v;
  S->depth++;
  if (S->depth >= S->alloc) {
    S->alloc += STACK_DIM;
    S->lifo = (pair *)realloc(S->lifo, S->alloc*sizeof(pair));
    if (!S->lifo)
      return 1;
  }
  return 0;
}

int stack_empty(stack *S)
{
  return (S->depth == 0);
}

unsigned long stack_present(stack *S, vertex_type v)
{
  unsigned long i;

  for (i = 0; i < S->depth; i++) {
    if (S->lifo[i].s == v)
      return i + 1;
  }
  return 0;
}

unsigned long stack_present_from_to(stack *S, unsigned long from, unsigned long to, vertex_type v)
{
  unsigned long i;

  for (i = from; i < to; i++) {
    if (S->lifo[i].s == v)
      return i + 1;
  }
  return 0;
}

void free_stack(stack *S)
{
  free(S->lifo);
  free(S);
}

void add_to_ht(stack *S, simple_hashtable *H)
{
  unsigned long i;

  for (i = 0; i < S->depth; i++)
    add_element(S->lifo[i].s, H);
}

void add_to_ht_part(stack *S, unsigned long from, simple_hashtable *H)
{
  unsigned long i;

  for (i = from; i < S->depth; i++)
    add_element(S->lifo[i].s, H);
}

unsigned long get_depth(stack *S)
{
  return S->depth;
}

vertex_type get_v_at_stack(stack *S, unsigned long i)
{
  return S->lifo[i].s;
}

int stack_has_loops(stack *S, stack *stack_prev)
{
  unsigned long i;

  for (i = 0; i < S->depth; i++) {
    if (stack_present(stack_prev, S->lifo[i].s))
      return 1;
  }
  return 0;
}

void print_stack(stack *S, char **orig_names)
{
  unsigned long i;

  for (i = 0; i < S->depth; i++)
    printf("%s ", orig_names[S->lifo[i].s]);
  printf("\n");
}
