#ifndef __STACK_H__
#define __STACK_H__

#include "hash_table.h"
#include "graph.h"

typedef struct pair {
  /* unsigned int d; */
  vertex_type s;
  vertex_list *next;
} pair;

typedef struct stack {
  unsigned long depth, alloc;
  pair *lifo;
} stack;

stack *init_stack();
pair top(stack *);
void update_top(stack *);
void update_top_rev(stack *);
void pop(stack *);
int push(stack *, vertex_type, vertex_list *);
void free_stack(stack *);
int stack_empty(stack *);
unsigned long stack_present(stack *, vertex_type );
unsigned long stack_present_from_to(stack *, unsigned long, unsigned long, vertex_type );
void add_to_ht(stack *, simple_hashtable *);
void add_to_ht_part(stack *, unsigned long, simple_hashtable *);
unsigned long get_depth(stack *);
/* void truncate_stack(stack *S, unsigned long from_depth, int); */
vertex_type get_v_at_stack(stack *S, unsigned long i);
int stack_has_loops(stack *S, stack *stack_prev);
void print_stack(stack *S, char **orig_names);
#endif
