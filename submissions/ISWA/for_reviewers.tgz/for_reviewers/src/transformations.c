#include "transformations.h"
#include "network.h"
#include "graph.h"
#include "hash_table.h"
#include "stack.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define PART_FOR_HT 0.5
#define BUFFER_LEN (1 << 10)
/* #define DBGDBG */

/* #define SIMPLE_DETOUR */
/* #define NESTED_DFS */
/* #define JOHNSON */
#define DETOUR_HEURISTICS

#if defined(SIMPLE_DETOUR)
static void detours_elimination_rec(network *N, vertex_type s, vertex_type t, simple_hashtable *valid);
#endif
#if defined(NESTED_DFS)
static void detours_elimination_rec(network *N, vertex_type s, vertex_type t, simple_hashtable *valid, stack *stack);
#endif
#if defined(JOHNSON)
static void johnson(network *N, hashtable **nodes_in_cycles, vertex_type **actual_cycles);
static void check_dfs(network *N, hashtable *nodes_in_cycles, vertex_type *actual_cycles);
static void set_bool(unsigned *b, unsigned long pos);
static double print_top(const char *string, ...);

typedef struct graph_list {
  graph *G;
  struct graph_list *next;
} graph_list;

static graph_list *conn_comp(graph *G, int, vertex_type v, graph_list *GL);
static graph *get_induced_graph(graph *G, simple_hashtable *H);
#endif
#ifdef DETOUR_HEURISTICS
static unsigned long check_dfs_b(network *N, stack *prev_stack, unsigned long from, unsigned long to, edges_hashtable *check_stack, simple_hashtable *detours);
static unsigned check_dfs_f(network *N, vertex_type s, vertex_type);
static simple_hashtable *computeW(graph *, simple_hashtable *);
static void chain_compact_detour(network *, simple_hashtable *, int);
#endif
static void reachable_reduction_base(network *N, int with_chains, int directed);
static void induced_graph(graph *, simple_hashtable *, vertex_type *, unsigned);

simple_hashtable *reachable_nodes_chains(graph *G, vertex_type s, vertex_type *t, int with_chains, int directed)
{
  stack *stack = init_stack();
  simple_hashtable *nodes_ok = init_simple_hashtable(G->num_vertices*PART_FOR_HT);
  unsigned long chain = 0, from_depth, num_ord = 0;
  double min_cost;
  unsigned int num_tbc = (directed? 1 : 2);
  push(stack, s, G->vertices[s]);
  add_element(s, nodes_ok);
  while (!stack_empty(stack)) {
    pair current = top(stack);
    if ((!t || current.s != *t) && current.next) {
      unsigned int tmp;
      unsigned long now = get_depth(stack);
      vertex_list *v, *v_save;
      update_top(stack);
      v = current.next;       //WARNING: does not work if t is the end of a chain and its ingoing degree is 1 (unlikely...)
      if (!is_present(v->v, nodes_ok) && ((t && v->v == *t) || G->out_deg[v->v] > 0)) {
	assert(add_element(v->v, nodes_ok) == 0);
	push(stack, v->v, G->vertices[v->v]);
      }
      if (with_chains) {
	/* chains are of course visited just once */
	if (chain == 0 && G->in_deg[v->v] == num_tbc && G->out_deg[v->v] == num_tbc) {
	  chain = 1;
	  from_depth = now;
	  min_cost = v->cost;
	}
	else if (chain > 0 && G->in_deg[v->v] == num_tbc && G->out_deg[v->v] == num_tbc) {
	  if (min_cost > v->cost) 
	    min_cost = v->cost;
	}
	else if (chain > 0 && !(G->in_deg[v->v] == num_tbc &&G->out_deg[v->v] == num_tbc)) {
	  unsigned long i, start;
	  if (min_cost > v->cost) 
	    min_cost = v->cost;
	  chain = 0;
	  if (exists_edge(get_v_at_stack(stack, from_depth - 1), v->v, G)) {
	    if (now - from_depth > 1) 
	      add_edge_cost(get_v_at_stack(stack, from_depth), v->v, min_cost, G);
	    start = from_depth + 1; /* if !(now - from_depth > 1), then now = from_depth + 1... */
	  }
	  else {
	    if (get_v_at_stack(stack, from_depth - 1) != v->v) 
	      add_edge_cost(get_v_at_stack(stack, from_depth - 1), v->v, min_cost, G);
	    start = from_depth;
	  }
	  for (i = start; i < now; i++) {
	    vertex_type tbd = get_v_at_stack(stack, i);
	    simple_erase_edge(G, get_v_at_stack(stack, i - 1), tbd);
	    simple_erase_vertex(G, tbd);
	    assert(remove_element(tbd, nodes_ok) == 1);
	  }
	  /* being inside a chain, the pointer on the stack is already null.. */
	  /* for (i = from_depth; i < now; i++) */
	  /*   pop_i(stack, i); */
	}
      }
    }
    else 
      pop(stack);
  }
  free_stack(stack);
  return nodes_ok;
}

static void reachable_reduction_base(network *N, int with_chains, int directed)
{
  simple_hashtable *nodes_ok = reachable_nodes_chains(N->G, N->s, &(N->t), with_chains, directed);
  graph *inv_G;
  vertex_type dummy;
  induced_graph(N->G, nodes_ok, &(N->t), 1);
  free_simple_hashtable(nodes_ok);
  inv_G = inverted_graph(N->G);
  nodes_ok = reachable_nodes_chains(inv_G, N->t, &(N->s), 0, 0);
  induced_graph(N->G, nodes_ok, (vertex_type *)0, 1);
  free_simple_hashtable(nodes_ok);
  free_graph(inv_G);
}

void only_reachable(network *N)
{
  reachable_reduction_base(N, 0, 0);
}

void reachable_and_chains(network *N, int directed)
{
  reachable_reduction_base(N, 1, directed);
}

static void induced_graph(graph *G, simple_hashtable *H, vertex_type *t, unsigned del_if_not_present)
{
  unsigned long i;
  vertex_list *vl, *tmp;
  if (H->num_stored + (t? 1 : 0) == G->num_vertices)
    return;
  for (i = 0; i < G->max_index; i++) {
    if ((G->in_deg[i] > 0 || G->out_deg[i] > 0) && (del_if_not_present? !is_present(i, H) : is_present(i, H))) {
      erase_vertex(G, i, 0);
    }
  }
  if (t)
    erase_vertex(G, *t, 1);
  recompute_maxdeg(G);
}

#if defined(SIMPLE_DETOUR)

void detours_elimination(network *N)
{
  if (N->G->num_vertices == 0)
    return;
  simple_hashtable *valid = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  unsigned long old_valid = valid->num_stored;
  add_element(N->t, valid);
  while (old_valid != valid->num_stored && valid->num_stored != N->G->num_vertices) {
    old_valid = valid->num_stored;
    detours_elimination_rec(N, N->s, N->t, valid);
  }
  induced_graph(N->G, valid, (vertex_type *)0, 1);
  free_simple_hashtable(valid);
}

static void detours_elimination_rec(network *N, vertex_type s, vertex_type t, simple_hashtable *valid)
{
  stack *stack = init_stack();
  simple_hashtable *visited = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  push(stack, s, N->G->vertices[s]);
  add_element(s, visited);
  while (!stack_empty(stack)) {
    pair current = top(stack);
    unsigned tmp;
    vertex_list *node_to;
    update_top(stack);
    if (current.next && current.s != N->t) {
      node_to = current.next;
      if (!is_present(current.s, valid) && is_present(node_to->v, valid) && !stack_present(stack, node_to->v)) 
	add_to_ht(stack, valid);
      if ((!is_present(node_to->v, visited)) && N->G->out_deg[node_to->v] > 0) {
	add_element(node_to->v, visited);
	push(stack, node_to->v, N->G->vertices[node_to->v]);
      }
    }
    else
      pop(stack);
  }
  free_stack(stack);
  free_simple_hashtable(visited);
}

#endif

#if defined(NESTED_DFS)

void detours_elimination(network *N)
{
  if (N->G->num_vertices == 0)
    return;
  simple_hashtable *valid = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  simple_hashtable *visited = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  stack *stack = init_stack();
  unsigned long old_valid = valid->num_stored;
  add_element(N->t, valid);
  while (old_valid != valid->num_stored && valid->num_stored != N->G->num_vertices) {
    old_valid = valid->num_stored;
    detours_elimination_rec(N, N->s, N->t, valid, stack);
    push(stack, N->s, N->G->vertices[N->s]);
    while (!stack_empty(stack)) {
      pair current = top(stack);
      unsigned tmp;
      vertex_list *node_to;
      update_top(stack);
      if (current.next && current.s != N->t) {
	node_to = current.next;
	if (!is_present(node_to->v, visited) && N->G->out_deg[node_to->v] > 0) {
	  detours_elimination_rec(N, node_to->v, N->t, valid, stack);
	  push(stack, node_to->v, N->G->vertices[node_to->v]);
	  add_element(node_to->v, visited);
	}
      }
      else 
	pop(stack);
    }
  }
  free_stack(stack);
  free_simple_hashtable(visited);
  induced_graph(N->G, valid, (vertex_type *)0, 1);
  free_simple_hashtable(valid);
}

static void detours_elimination_rec(network *N, vertex_type s, vertex_type t, simple_hashtable *valid, stack *stack_prev)
{
  stack *stack = init_stack();
  simple_hashtable *visited = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  push(stack, s, N->G->vertices[s]);
  add_element(s, visited);
  while (!stack_empty(stack)) {
    pair current = top(stack);
    unsigned tmp;
    vertex_list *node_to;
    update_top(stack);
    if (!stack_has_loops(stack, stack_prev) && current.next && current.s != N->t) {
      node_to = current.next;
      if (is_present(node_to->v, valid) && !stack_present(stack, node_to->v) && !stack_present(stack_prev, node_to->v)) {
      /* without !is_present(current.s, valid) it fails on very simple examples; with, it fails on bigger examples */
      /* if (!is_present(current.s, valid) && is_present(node_to->v, valid) && !stack_present(stack, node_to->v) && !stack_present(stack_prev, node_to->v)) { */
	add_to_ht(stack, valid);
	add_to_ht(stack_prev, valid);
      }
      else if (!is_present(node_to->v, visited) && N->G->out_deg[node_to->v] > 0) {
	add_element(node_to->v, visited);
	push(stack, node_to->v, N->G->vertices[node_to->v]);
      }
    }
    else
      pop(stack);
  }
  free_stack(stack);
  free_simple_hashtable(visited);
}

#endif

#if defined(JOHNSON)


static graph *get_induced_graph(graph *G, simple_hashtable *H)
{
  unsigned long i;
  vertex_list *vl, *tmp;
  graph *ret;
  if (H->num_stored == G->num_vertices)
    return copy_graph(G);
  ret = init_graph(1);
  for (i = 0; i < G->max_index; i++) {
    if ((G->in_deg[i] > 0 || G->out_deg[i] > 0) && is_present(i, H)) {
      add_node(i, ret);
      for (vl = G->vertices[i]; vl; vl = vl->next)
	add_edge_cost(i, vl->v, vl->cost, ret);
    }
  }
  return ret;
}

static void set_bool(unsigned *b, unsigned long pos)
{
  b[pos/(8*sizeof(unsigned))] |= (1 << (pos%(8*sizeof(unsigned))));
}

static void johnson(network *N, hashtable **nodes_in_cycles, vertex_type **actual_cycles)
{
  /* stack *stack = init_stack(); */
  /* simple_hashtable **B = (simple_hashtable **)calloc(N->G->num_vertices, sizeof(simple_hashtable *)); */
  /* unsigned *blocked = (unsigned *)calloc(N->G->num_vertices/(8*sizeof(unsigned)), sizeof(unsigned)); */
  /* unsigned long i; */
  /* unsigned f; */
  /* for (i = 0; i < N->G->num_vertices; i++) */
  /*   B[i] = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT); */
  /* f = 0; */
  /* push(stack, N->s, N->G->vertices[N->s]); */
  /* set_bool(blocked, N->s);  */
  /* while (!stack_empty(stack)) { */
  /*   vertex_list *v; */
  /*   pair current = top(stack); */
  /*   update_top(stack); */
  /*   v = current.next; */
  /*   if (!is_present(v->v, nodes_ok) && ((t && v->v == *t) || G->out_deg[v->v] > 0)) { */
  /*     assert(add_element(v->v, nodes_ok) == 0); */
  /*     push(stack, v->v, G->vertices[v->v]); */
  /*   } */
  /* } */
}

static void check_dfs(network *N, hashtable *nodes_in_cycles, vertex_type *actual_cycles)
{
}

static graph_list *conn_comp(graph *G, int directed, vertex_type v, graph_list *GL)
{
  vertex_type *order = (vertex_type *)calloc(G->num_vertices, sizeof(vertex_type));
  simple_hashtable *nodes_ok = reachable_nodes_chains(G, v, (vertex_type *)0, 0, directed);
  graph *inv_G;
  unsigned long i;
  simple_hashtable *part_nodes_ok;
  graph_list *ret = GL, *tmp;
  free_simple_hashtable(nodes_ok);
  inv_G = inverted_graph(G);
  nodes_ok = init_simple_hashtable(G->num_vertices*PART_FOR_HT);
  for (i = 0; nodes_ok->num_stored < inv_G->num_vertices; i++) {
    if (!is_present(order[i], nodes_ok)) {
      part_nodes_ok = reachable_nodes_chains(inv_G, order[i], (vertex_type *)0, 0, directed);
      tmp = (graph_list *)calloc(1, sizeof(graph_list));
      tmp->G = get_induced_graph(G, part_nodes_ok);
      tmp->next = ret;
      ret = tmp;
      merge_simple_hashtables(nodes_ok, part_nodes_ok);
      free_simple_hashtable(part_nodes_ok);
    }
  }
  free_simple_hashtable(nodes_ok);
  free_graph(inv_G);
  return ret;
}

#endif

#if defined(DETOUR_HEURISTICS)

void detours_elimination(network *N, int directed)
{
  stack *stack = init_stack();
  simple_hashtable *detours = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT), *W;
  simple_hashtable *visited = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  simple_hashtable *stack_ht = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  edges_hashtable *check_stack = init_edges_hashtable(N->G->num_vertices*PART_FOR_HT);
  push(stack, N->s, N->G->vertices[N->s]);
  add_element(N->s, visited);
  add_element(N->s, stack_ht);
  while (!stack_empty(stack)) {
    pair current = top(stack);
    if (current.next) {
      unsigned int tmp;
      unsigned long now = get_depth(stack);
      vertex_list *v;
      update_top(stack);
      v = current.next;
      if (!is_present(v->v, visited) && N->G->out_deg[v->v] > 0) {
	assert(add_element(v->v, visited) == 0);
	push(stack, v->v, N->G->vertices[v->v]);
	add_element(v->v, stack_ht);
	add_element_eh(current.s, v->v, check_stack);
      }
      else if (is_present(v->v, stack_ht)) {
	unsigned long pos = stack_present(stack, v->v); /* this is actually the next one, but ok */
	unsigned long i, to;
	add_element_eh(current.s, v->v, check_stack);
	for (i = 0; i < (pos >= 2? pos - 2 : pos - 1); i++)
	  /* for (i = 0; i < pos - 1; i++) */ /* EXPS */
	  remove_element_eh(get_v_at_stack(stack, i), get_v_at_stack(stack, i + 1), check_stack);
	to = check_dfs_b(N, stack, pos, get_depth(stack), check_stack, detours);
	for (i = pos; i < to; i++) {
	  if (!check_dfs_f(N, get_v_at_stack(stack, i), v->v))
	    add_element(get_v_at_stack(stack, i), detours);
	}
	remove_element_eh(current.s, v->v, check_stack);
	for (i = 0; i < (pos >= 2? pos - 2 : pos - 1); i++)
	  /* for (i = 0; i < pos - 1; i++) */ /* EXPS */
	  add_element_eh(get_v_at_stack(stack, i), get_v_at_stack(stack, i + 1), check_stack);
      }
    }
    else {
      pop(stack);
      remove_element(current.s, stack_ht);
      if (!stack_empty(stack)) {
	pair p = top(stack);
	remove_element_eh(p.s, current.s, check_stack);
      }
    }
  }
  free_stack(stack);
  free_simple_hashtable(visited);
  free_simple_hashtable(stack_ht);
  free_edges_hashtable(check_stack);
  W = computeW(N->G, detours);
#ifdef DBGDBG
  printf("detours:\n");
  print_all(detours, N->G->orig_names);
  printf("W:\n");
  print_all(W, N->G->orig_names);
#endif
  induced_graph(N->G, detours, (vertex_type *)0, 0);
#ifdef CC_AFTER_DETOUR
  print_stats(N->G, N, directed, "mid detours elimination, before chain compaction");
  free_simple_hashtable(detours);
  chain_compact_detour(N, W, directed);
#endif
  free_simple_hashtable(W);
}

static unsigned long check_dfs_b(network *N, stack *prev_stack, unsigned long from, unsigned long to, edges_hashtable *check_stack, simple_hashtable *detours)
{
  stack *stack = init_stack();
  simple_hashtable *visited = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  push(stack, N->s, N->G->vertices[N->s]);
  add_element(N->s, visited);
  while (!stack_empty(stack)) {
    pair current = top(stack);
    if (current.next) {
      vertex_list *v;
      update_top(stack);
      v = current.next;
#ifdef DONOTGOTHROUGHDETOURS
      if (!is_present_eh(current.s, v->v, check_stack) && !is_present(v->v, detours) && !is_present(v->v, visited) && N->G->out_deg[v->v] > 0) {
#else
      if (!is_present_eh(current.s, v->v, check_stack) && !is_present(v->v, visited) && N->G->out_deg[v->v] > 0) {
#endif
	unsigned long pos = stack_present_from_to(prev_stack, from, to, v->v); //from incl, to excl
	if (pos) {
	  to = pos - 1; // this is the actual position, as stack_present_from_to is +1
	  if (from >= to) //possible only if pos = from + 1 (i.e., the position was from)
	    break;
	}
	assert(add_element(v->v, visited) == 0);
	push(stack, v->v, N->G->vertices[v->v]);
      }
    }
    else 
      pop(stack);
  }
  free_stack(stack);
  free_simple_hashtable(visited);
  return to;  
}

static unsigned check_dfs_f(network *N, vertex_type s, vertex_type to_be_avoided)
{
  unsigned ret = 0;
  stack *stack = init_stack();
  simple_hashtable *visited = init_simple_hashtable(N->G->num_vertices*PART_FOR_HT);
  push(stack, s, N->G->vertices[s]);
  add_element(s, visited);
  while (!stack_empty(stack)) {
    pair current = top(stack);
    if (current.next) {
      vertex_list *v;
      update_top(stack);
      v = current.next;
      if (!is_present(v->v, visited)) {
	if (v->v == N->t) {
	  ret = 1;
	  break;
	}
	else if (v->v != to_be_avoided && N->G->out_deg[v->v] > 0) {
	  assert(add_element(v->v, visited) == 0);
	  push(stack, v->v, N->G->vertices[v->v]);
	}
      }
    }
    else 
      pop(stack);
  }
  free_stack(stack);
  free_simple_hashtable(visited);
  return ret;
}

static simple_hashtable *computeW(graph *G, simple_hashtable *D)
{
  unsigned i;
  simple_hashtable *ret = init_simple_hashtable(G->num_vertices*PART_FOR_HT);

  for (i = 0; i < G->max_index; i++) {
    vertex_list *tmp;
    int ok = 0;
    if (G->in_deg[i] == 0 || G->out_deg[i] == 0 || is_present(i, D))
      continue;
    if (is_present(i, D)) {
      ok = 1;
      assert(add_element(i, ret) == 0);
    }
    for (tmp = G->vertices[i]; tmp; tmp = tmp->next) {
      if (ok || is_present(tmp->v, D)) {
	assert(add_element(i, ret) == 0);
	break;
      }
    }
  }
  return ret;
}

#ifdef WITH_LIST
static void chain_compact_detour(graph *G, simple_hashtable *W, int directed)
{
  nodes_list *i = (nodes_list *)0;
  int dummy, max = -1;
  unsigned int num_tbc = (directed? 1 : 2);
  graph *inv_G = (graph *)0;
  for (i = iter_ht(W, i, &dummy); i; i = iter_ht(W, i, &dummy)) {
    if (G->in_deg[i->index] == num_tbc && G->out_deg[i->index] == num_tbc) {
      vertex_list *simple_stack, *p, *last;
      double min_cost = G->vertices[i->index]->cost; //only one edge...
      unsigned long length = 1; // number of edges in chain
      vertex_type start, end;
      if (inv_G == (graph *)0)
	inv_G = inverted_graph(G);
      start = inv_G->vertices[i->index]->v;
      assert(simple_stack = (vertex_list *)calloc(1, sizeof(vertex_list)));
      simple_stack->v = start;
      last = simple_stack;
      while(G->in_deg[start] == num_tbc && G->out_deg[start] == num_tbc) {
	if (min_cost > G->vertices[start]->cost)
	  min_cost = G->vertices[start]->cost;
	start = inv_G->vertices[start]->v;
	assert(p = (vertex_list *)calloc(1, sizeof(vertex_list)));
	p->v = start;
	p->next = simple_stack;
	simple_stack = p;
	length++;
      }
      end = i->index;
      while(G->in_deg[end] == num_tbc && G->out_deg[end] == num_tbc) {
	if (min_cost > G->vertices[end]->cost)
	  min_cost = G->vertices[end]->cost;
	assert(last->next = (vertex_list *)calloc(1, sizeof(vertex_list)));
	last->next->v = end;
	last = last->next;
	length++;
	end = G->vertices[end]->v;
      }
#ifdef DBGDBG
      for(p = simple_stack; p; p = p->next)
	printf("%s ", G->orig_names[p->v]);
      printf("\n");
#endif
      if (exists_edge(start, end, G)) {
	if (length > 2) {
#ifdef DBGDBG
	  printf("exists, %s->%s\n", G->orig_names[simple_stack->next->v], G->orig_names[end]);
#endif
	  add_edge_cost(simple_stack->next->v, end, min_cost, G);
	  p = simple_stack;
	  simple_stack = simple_stack->next;
	  free(p);
	}
	else {
#ifdef DBGDBG
	  printf("exists\n");
#endif
	  p = simple_stack;
	  simple_stack = simple_stack->next;
	  free(p);
	  //simple_stack now empty
	}
      }
      else {
	add_edge_cost(start, end, min_cost, G);
#ifdef DBGDBG
	printf("doesn't exist, %s->%s\n", G->orig_names[start], G->orig_names[end]);
#endif
      }
#ifdef DBGDBG
      fflush(stdout);
#endif
      while (simple_stack->next) {
	vertex_type tbd = simple_stack->next->v;
	simple_erase_edge(G, simple_stack->v, tbd);
	simple_erase_vertex(G, tbd);
	p = simple_stack;
	simple_stack = simple_stack->next;
	free(p);
      }
      if (simple_stack) //if not empty, then only one element
	free(simple_stack);
    }
  }
  if (inv_G)
    free_graph(inv_G);
}
#else
static void chain_compact_detour(network *N, simple_hashtable *W, int directed)
{
  nodes_list *i = (nodes_list *)0;
  int dummy, max = -1;
  unsigned int num_tbc = (directed? 1 : 2);
  graph *inv_G = (graph *)0;
  stack *simple_stack;
  for (i = iter_ht(W, i, &dummy); i; i = iter_ht(W, i, &dummy)) {
    /* if (N->G->in_deg[i->index] == 0 && i->index != N->s) */
    /*   erase_vertex(N->G, i->index, 0); */
    /* if (N->G->out_deg[i->index] == 0 && i->index != N->t) */
    /*   erase_vertex(N->G, i->index, 0); */
    if (N->G->in_deg[i->index] == num_tbc && N->G->out_deg[i->index] == num_tbc) {
      unsigned long firstb = 0, j;
      unsigned char delete_all = 0;
      double min_cost = N->G->vertices[i->index]->cost; //only one edge...
      vertex_type start, end;
      if (inv_G == (graph *)0) {
	inv_G = inverted_graph(N->G);
	simple_stack = init_stack();
      }
      start = inv_G->vertices[i->index]->v;
      push(simple_stack, start, (vertex_list *)0);
      while(N->G->in_deg[start] == num_tbc && N->G->out_deg[start] == num_tbc) {
	if (min_cost > N->G->vertices[start]->cost)
	  min_cost = N->G->vertices[start]->cost;
	start = inv_G->vertices[start]->v;
	if (stack_present(simple_stack, start)) {
	  delete_all = 1;
	  break;
	}
	push(simple_stack, start, (vertex_list *)0);
      }
      if (!delete_all) {
	end = i->index;
	/* if (get_depth(simple_stack) >= 1) */ /* always true, at least there is the start node */
	firstb = get_depth(simple_stack) - 1;
	while(N->G->in_deg[end] == num_tbc && N->G->out_deg[end] == num_tbc) {
	  if (min_cost > N->G->vertices[end]->cost)
	    min_cost = N->G->vertices[end]->cost;
	  if (stack_present(simple_stack, end)) {
	    delete_all = 1;
	    break;
	  }
	  push(simple_stack, end, (vertex_list *)0);
	  end = N->G->vertices[end]->v;
	}
      }
      if (!delete_all) {
	/*
	  for a chain
	  v_1, v_2, ..., v_n
	  where we element in W was v_i, v_1 is outside the chain and v_n is inside the chain,
	  simple_stack is:
	  v_i v_{i-1} ... v_1 v_{i+1} ... v_n
	  firstb is the index of v_1
	*/
	for (j = 0; firstb && j <= firstb/2; j++) {
	  vertex_type tmp = get_v_at_stack(simple_stack, j);
	  simple_stack->lifo[j].s = simple_stack->lifo[firstb - j].s;
	  simple_stack->lifo[firstb - j].s = tmp;
	}
	if (exists_edge(start, end, N->G)) {
	  if (get_depth(simple_stack) > 2) 
	    add_edge_cost(get_v_at_stack(simple_stack, 1), end, min_cost, N->G);
	  firstb = 1;
	}
	else {
	  add_edge_cost(start, end, min_cost, N->G);
	  firstb = 0;
	}
      }
      for (j = firstb; j + 1 < get_depth(simple_stack); j++) {
	vertex_type tbd = get_v_at_stack(simple_stack, j + 1);
	simple_erase_edge(N->G, get_v_at_stack(simple_stack, j), tbd);
	simple_erase_vertex(N->G, tbd);
      }
      simple_stack->depth = 0;
    }
  }
  if (inv_G) {
    free_graph(inv_G);
    free_stack(simple_stack);
  }
}
#endif
#endif

static double print_top(const char *string, ...)
{
  static char to_be_exec[BUFFER_LEN]; 
  FILE *stream;
  int count = 0;
  char *tmp, *tmp2;

  if (strcmp(string, "") != 0) {
    sprintf(to_be_exec, "cat /proc/%d/stat | awk '{printf(\"%%e seconds, %%s bytes of memory usage, \", ($14 + $15)/%ld, $23)}'; \
cat /proc/%d/status | grep VmPeak | awk '{printf(\"%%s kB of memory peak and \", $2)}'; \
ps -h -oetime %d | awk '{print $1, \"elapsed time\"}'", getpid(), sysconf(_SC_CLK_TCK), getpid(), getpid());
    fprintf(stdout, "\nExecution time and memory used at ");
    va_list args;
    va_start(args, string);
    vfprintf(stdout, string, args);
    fprintf(stdout, ": ");
    fflush(stdout);
    system(to_be_exec);
    fflush(stdout);
    va_end(args);
  }
  /* sprintf(to_be_exec, "/proc/%d/stat", getpid()); */
  /* stream = fopen(to_be_exec, "r"); */
  /* fgets(to_be_exec, BUFFER_LEN, stream); */
  /* fclose(stream); */
  /* tmp = to_be_exec; */
  /* while (count < 13) { */
  /*   tmp = strchr(tmp + 1, ' '); */
  /*   count++; */
  /* } */
  /* tmp2 = strchr(tmp + 1, ' '); */
  /* *tmp2 = '\0'; */
  /* return atof(tmp)/100; */
  return 0;
}

void print_stats(graph *G, network *N, int directed, char *info)
{
  print_top(info);
  printf("Statistics on the network %s\n\tNumber of nodes: %lu\n\tNumber of allocated nodes: %lu\n\tNumber of edges: %lu\n\tMaximum in degree: %lu (node %s)\n\tMaximum out degree: %lu (node %s)\n", (info != (char *)0? info : ""), G->num_vertices, G->num_vertices_alloc, G->num_edges/(directed? 1 : 2), G->max_indeg, G->orig_names[G->argmax_indeg], G->max_outdeg, G->orig_names[G->argmax_outdeg]);
  if (N)
    printf("\tsource %lu (node %s) with out degree %lu\n\ttarget %lu (node %s) with in degree %lu\n", N->s, G->orig_names[N->s], N->G->out_deg[N->s], N->t, G->orig_names[N->t], N->G->in_deg[N->t]);
  fflush(stdout);
}
