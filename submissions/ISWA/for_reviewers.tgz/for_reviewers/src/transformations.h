#ifndef __TRANSFORMATIONS_H__
#define __TRANSFORMATIONS_H__
#include "network.h"
#include "graph.h"
#include "hash_table.h"

#define CURR_VERSION_VULN "1.2"

void only_reachable(network *N);
void reachable_and_chains(network *N, int);
void detours_elimination(network *N, int directed);
void chains_elimination(network *N, int directed);
simple_hashtable *reachable_nodes_chains(graph *G, vertex_type s, vertex_type *t, int with_chains, int directed);
void print_stats(graph *G, network *N, int directed, char *info);

#endif
