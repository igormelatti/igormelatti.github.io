if [ $# -lt 1 ]
then
    echo Please provide the input LP file and optionally the budget, if it need to be changed
    exit
fi

if [ $# -eq 2 ]
then
    awk '{if (FNR == 4) {for (i = 1; i <= NF - 1; i++) printf("%s ", $i); print '$2'} else print}' $1 > $1.$2.lp
    ./src/glpk-5.0/examples/glpsol --lp $1.$2.lp
else
    ./src/glpk-5.0/examples/glpsol --lp $1
fi

