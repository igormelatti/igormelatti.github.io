LD_LIBRARY_PATH=./src/glpk-5.0/src/.libs/ ./src/main $*
