startstate begin end;

rule true ==> begin end;
