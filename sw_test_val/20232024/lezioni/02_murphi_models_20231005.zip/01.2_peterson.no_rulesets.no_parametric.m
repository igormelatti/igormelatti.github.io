/************************ PART ONE: CONSTANTS, TYPES AND GLOBAL VARIABLES ************************/

Const		/* keywords are NOT case-sensitive: you can write ConST, TYPE, var, rULE and it's ok (as in Pascal) */
  N : 2;	/* identificators are case-sensitive: n and N, pid and pId etc. DIFFER */

Type
  pid : 1..N;				/* simple type: integer subrange */
  label_t : Enum{L0, L1, L2, L3, L4};	/* simple type: enumerative type */

Var
  P : Array [ pid ] Of label_t;
  Q : Array [ pid ] Of boolean;
  turn : pid;				

/************************ PART TWO: FUNCTIONS AND PROCEDURES ************************/

/* empty, neither functions nor procedures needed */

/************************ PART THREE: RULES, STARTSTATES AND INVARIANTS ************************/

/* This is for process one */

Rule "L0 -> L1"
  P[1] = L0  ==>	/* guard */
Begin			/* body */
  Q[1] := true;
  P[1] := L1; 
End;			/* end body */

Rule "execute assign turn 1"
  P[1] = L1  ==>
Begin
  turn := 1;
  P[1] := L2; 
End;

Rule "L2 -> L3 or L2 -> L2"
  P[1] = L2  ==>
Begin
  If (!Q[2] | turn = 2) Then 
    P[1] := L3; 
  End;
End;

Rule "L3 -> L4"
  P[1] = L3  ==>
Begin
  P[1] := L4; 
End;

Rule "L4 -> L0"
  P[1] = L4  ==>
Begin
  Q[1] := false;
  P[1] := L0;
End;

Startstate
Begin 
  For k : pid Do 
    P[k] := L0;
    Q[k] := false;
  End;
  turn := 1;
End;

/************ This is for process two ************/

Rule "L0 -> L1"
  P[2] = L0  ==>
Begin
  Q[2] := true;
  P[2] := L1; 
End;

Rule "L1 -> L2"
  P[2] = L1  ==>
Begin
  turn := 2;
  P[2] := L2; 
End;

Rule "L2 -> L3 or L2 -> L2"
  P[2] = L2  ==>
Begin
  If (!Q[1] | turn = 1) Then 
    P[2] := L3; 
  End;
End;

Rule "L3 -> L4"
  P[2] = L3  ==>
Begin
  P[2] := L4; 
End;

Rule "L4 -> L0"
  P[2] = L4  ==>
Begin
  Q[2] := false;
  P[2] := L0;
End;

Startstate
Begin
  For k : pid Do
    P[k] := L0;
    Q[k] := false;
  End;
  turn := 2;
End;

Invariant "mutual exclusion"
!(P[1] = L3 & P[2] = L3) 
/* or equivalently:
  
  (P[1] != L3 | P[2] != L3)
  
  (P[1] = L3 -> P[2] != L3) 

*/
