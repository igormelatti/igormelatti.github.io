Const
  N : 2;

Type
  pid : 1..N;
  label_t : Enum{L0, L1, L2, L3, L4};

Var
  P : Array [ pid ] Of label_t;
  Q : Array [ pid ] Of boolean;
  turn : pid;

Ruleset i : pid Do		/* Murphi will consider each of the enclosed rules as duplicated:
				   one with i replaced by 1 and the other with i replaced by 2 */

  Rule "L0 -> L1" P[i] = L0  ==>
  Begin
    Q[i] := true;
    P[i] := L1; 
  End;

  Rule "L1 -> L2" P[i] = L1  ==>
  Begin
    turn := i;
    P[i] := L2; 
  End;

  Rule "L2 -> L2 or L2 -> L3" P[i] = L2  ==>
  Var
    j : pid;			/* j is a local variable */
  Begin
    j := (i = 1? 2 : 1); 	/* j is used to compute the "other" process */
    If ( !Q[j] | turn = j ) Then 
      P[i] := L3; 
    End;
  End;

  Rule "L3 -> L4" P[i] = L3  ==>
  Begin
    P[i] := L4; 
  End;

  Rule "L4 -> L0" P[i] = L4  ==>
  Begin
    Q[i] := false;
    P[i] := L0;
  End;

  Startstate
  Begin
    For k : pid Do
      P[k] := L0;
      Q[k] := false;
    End;
    turn := i;
  End;
  
End; /* Ruleset */

Invariant "mutual exclusion"
 !(P[1] = L3 & P[2] = L3)
 
