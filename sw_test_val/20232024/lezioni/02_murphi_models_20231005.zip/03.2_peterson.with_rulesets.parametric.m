Const
  N: 2; 	/* this protocol only works for 2 processes, but here we write the model 
  		   so that you can replace 2 with any integer */

Type
  pid: 1..N;
  label_t: Enum{L0, L1, L2, L3, L4};

Var
  P: Array [ pid ] Of label_t;
  Q: Array [ pid ] Of boolean;
  turn: pid;

/*
  S = {(L0, L0, false, false, 1), (L0, L0, false, false, 2), ...}
  S_0 = {(L0, L0, false, false, 1), (L0, L0, false, false, 2)}
  R = {(s_1 = (L1, L2, false, true, 1), (L2, L2, false, true, 1)), ((L1, L2, false, true, 1), s_2 = (L2, L3, false, true, 1)), ...}
  (P2 = L2) in L(s_1)
  (Q1 = false) in L(s_1)
  (turn = 1) in L(s_2)
  (P2 = L3) in L(s_2)
*/

Ruleset i: pid  Do

  Rule "execute assign Qi true"
    P[i] = L0  ==>
  Begin
    Q[i] := true;
    P[i] := L1; 
  End;

Rule "execute assign turn i"
    P[i] = L1  ==>
  Begin
    turn := i;
    P[i] := L2; 
  End;

  Rule "execute wait until"
    P[i] = L2  ==>
  Var
    j : pid;
  Begin
    j := i%N + 1;	/* take the "following" process, assuming they are in a circle */
    If ( !Q[j] | turn = j )
    Then 
      P[i] := L3; 
    End;
  End;

  /* The following rule is to some extent equivalent to the preceding one; 
     we'll see the difference when we'll speak about the Murphi verification algorithm */
  /*Rule "execute wait until"
    P[i] = L2 & (!Q[i%N + 1] | turn = i%N + 1) ==>
  Begin
    P[i] := L3; 
  End;*/

  Rule "execute critical section"
    P[i] = L3  ==>
  Begin
    P[i] := L4; 
  End;

  Rule "execute assign Qi false"
    P[i] = L4  ==>
  Begin
    Q[i] := false;
    P[i] := L0;
  End;

  Startstate
  Begin
    For k:pid Do
      P[k] := L0;
      Q[k] := false;
    End; /* For */
    turn := i;
  End;
  
End; /* Ruleset */

/*Invariant "mutual exclusion"
!(Exists i1: pid Do
    Exists i2: pid Do
      (i1 != i2 & P[i1] = L3 & P[i2] = L3 
      )
    End  
  End
); 
*/
Invariant true;
/* equivalently:
Invariant "mutual exclusion"
Forall i1: pid Do
  Forall i2: pid Do
    (i1 != i2 & P[i1] = L3 -> P[i2] != L3)
  End  
End
*/
