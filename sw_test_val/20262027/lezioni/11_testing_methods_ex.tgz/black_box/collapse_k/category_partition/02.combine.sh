../../pict/pict-main/pict 02.combine.txt | tee 02.combine.res.txt
echo -n Number of generated combinations:" "
awk 'FNR > 1{print}' 02.combine.res.txt | wc -l
echo -n Number of total combinations:" "
egrep -v '^if' 02.combine.txt > 02.combine.noconstraints.txt
../../pict/pict-main/pict 02.combine.noconstraints.txt /o:`awk '{if (NF > 0) cnt++}END{print cnt}' 02.combine.noconstraints.txt` | awk 'FNR > 1{print}' | wc -l
