python3 03.write_tc.py 02.combine.res.txt
