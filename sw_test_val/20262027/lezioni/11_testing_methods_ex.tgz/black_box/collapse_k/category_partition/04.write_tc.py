import sys
import random
import string
import re

VERY_BIG_NUM = 2**10
MIN_CONS_SPACES = 1
MAX_CONS_SPACES = 5

def formula(length, spaces):
    first = 1 if spaces > length//2 else 0
    A = (length + (1 if length%3 == 2 else 0))//3
    B = 2*A + (length + 1)%3
    if spaces < B:
        return (first, spaces//2)
    return (first, A - (spaces - B))

def insert_spaces(ret, slen, where_spaces, k_val):
    result = [ret, ret]
    where_spaces.sort(reverse = True, key = lambda x: x[0])
    for [i, j] in where_spaces:
        result[0] = result[0][ : i] + " "*j + result[0][i : ]
        result[1] = result[1][ : i] + " "*(1 if j == k_val else j) + result[1][i : ]
    if slen > len(result[0]):
        result[0] += " "*(slen - len(result[0]))
        result[1] += " "*(1 if k_val == slen - len(result[0]) else slen - len(result[0]))
    return result

def random_char(curr):
    ret = curr[0]
    j = 0
    randoms = []
    while True:
        new_j = curr[0].find("0", j)
        if new_j == -1:
            break
        randoms += [random.choice(list(string.ascii_letters))]
        ret = ret[:new_j] + randoms[-1] + curr[0][new_j + 1: ]
        j = new_j + 1
    ret2 = curr[1]
    j = 0
    i = 0
    while True:
        new_j = curr[1].find("0", j)
        if new_j == -1:
            break
        ret2 = ret2[:new_j] + randoms[i] + curr[1][new_j + 1: ]
        j = new_j + 1
        i += 1
    return [ret, ret2]

def read_slen(ar):
    if ar[0] in ["0", "1"]:
        return int(ar[0])
    elif ar[0] == "2_100":
        return random.randint(2, 100)
    else:
        return random.randint(101, VERY_BIG_NUM)

def read_spaces_num(ar, slen):
    if ar[1] in ["0", "1"]:
        return int(ar[1])
    else:
        nums = ar[1].split("l")
        return round(int(nums[0])*slen/int(nums[1]))

def read_adj_occ_cons_spaces_num(ar, slen, spaces_num):
    if ar[2] in ["0", "1"]:
        occ_cons_spaces_num = int(ar[2])
    else:
        occ_cons_spaces_num = spaces_num//int(ar[2].split("_")[1])
    if slen <= 1:
        occ_cons_spaces_num = 0
        lims = (0, 0)
    else:
        lims = formula(slen, spaces_num)
        if occ_cons_spaces_num < lims[0] or occ_cons_spaces_num > lims[1]:
            occ_cons_spaces_num = random.randint(lims[0], lims[1])
    return (occ_cons_spaces_num, lims[1])

def get_where_spaces_num(slen, spaces_num, occ_cons_spaces_num, occ_cons_k_spaces_num, k_val):
    where_spaces_single = []
    where_spaces_k_cons = random.sample(range(slen - spaces_num + 1), occ_cons_k_spaces_num)
    where_spaces_num = [[i, k_val] for i in where_spaces_k_cons]
    where_spaces_cons = []
    if occ_cons_k_spaces_num < occ_cons_spaces_num:
        where_spaces_cons = random.sample(set(range(slen - spaces_num + 1)).difference(set(where_spaces_k_cons)), occ_cons_spaces_num - occ_cons_k_spaces_num)
        where_spaces_num += [[i, 2] for i in where_spaces_cons]
    to_be_distr = spaces_num - k_val*occ_cons_k_spaces_num - 2*(occ_cons_spaces_num - occ_cons_k_spaces_num)
    while to_be_distr > 0:
        place = random.randint(0, slen - spaces_num)
        if place in where_spaces_k_cons:
            incr = random.randint(1, to_be_distr)
            where_spaces_num[where_spaces_k_cons.index(place)][1] += incr
        elif place in where_spaces_cons:
            incr = random.randint(1, to_be_distr)
            where_spaces_num[where_spaces_cons.index(place)][1] += incr
        else:
            incr = 1
            if place in where_spaces_single:
                continue
            where_spaces_num += [[place, incr]]
            where_spaces_single += [place]
        to_be_distr -= incr
        if to_be_distr == 0:
            break
    return where_spaces_num

def read_adj_k_val(ar, slen):
    if ar[3] in ["0", "1"]:
        k_val = int(ar[3])
        #already ok vs. k_s
    elif ar[3] == "neg":
        k_val = random.randint(-VERY_BIG_NUM, -1)
        #already ok vs. k_s
    elif ar[3][:3] == "gt_":
        if ar[5] == "eq":
            #from pict, slen is either 2_100 or gt_100
            minval = int(ar[3].split("_")[1])
            slen = max(slen, minval)
            k_val = slen
        elif ar[5] == "lt":
            #from pict, slen > 1
            minval = int(ar[3].split("_")[1])
            slen = max(slen, minval + 1)
            k_val = random.randint(minval, slen - 1)
        else:
            #from pict, slen may be any
            slen = max(slen, VERY_BIG_NUM - 1)
            k_val = random.randint(slen + 1, VERY_BIG_NUM)
    else:
        if ar[5] == "eq":
            #from pict, slen in [2, 100]
            slen = min(slen, int(ar[3].split("_")[1]))
            k_val = slen
        elif ar[5] == "lt":
            #from pict, slen > 1
            minval = int(ar[3].split("_")[0])
            maxval = int(ar[3].split("_")[1])
            slen = max(slen, maxval + 1)
            k_val = random.randint(minval, slen - 1)
        else:
            #from pict, slen < 100
            minval = int(ar[3].split("_")[0])
            maxval = int(ar[3].split("_")[1])
            slen = min(slen, minval - 1)
            k_val = random.randint(slen + 1, maxval)
    return (k_val, slen)

def read_adj_k_cons(ar, slen, spaces_num, occ_cons_spaces_num, lim, k_val):
    if ar[4] in ["0", "1"]:
        occ_cons_k_spaces_num = int(ar[4])
    else:
        occ_cons_k_spaces_num = random.randint(2, VERY_BIG_NUM)
    occ_cons_k_spaces_num = min(occ_cons_spaces_num, occ_cons_k_spaces_num)
    if occ_cons_k_spaces_num != 0:
        occ_cons_k_spaces_num = min((lim - occ_cons_spaces_num)//k_val, occ_cons_k_spaces_num)
    return occ_cons_k_spaces_num

def print_tc(ar):
    slen = read_slen(ar)
    (k_val, slen) = read_adj_k_val(ar, slen)
    if slen == 0:
        return ("", k_val, "")
    (k_val, slen) = read_adj_k_val(ar, slen)
    spaces_num = read_spaces_num(ar, slen)
    if spaces_num == slen:
        return (" "*slen, k_val, " ")
    (occ_cons_spaces_num, lim) = read_adj_occ_cons_spaces_num(ar, slen, spaces_num)
    occ_cons_k_spaces_num = read_adj_k_cons(ar, slen, spaces_num, occ_cons_spaces_num, lim, k_val)
    where_spaces_num = get_where_spaces_num(slen, spaces_num, occ_cons_spaces_num, occ_cons_k_spaces_num, k_val)
    ret = "0"*(slen - spaces_num)
    ret = insert_spaces(ret, slen, where_spaces_num, k_val)
    ret = random_char(ret)
    return (ret[0], k_val, ret[1])

if (len(sys.argv) != 2):
    print("Provide the file with the combinations")
else:
    f = open(sys.argv[1], "r")
    content = f.readlines()
    f.close()
    for c in content[1:]:
        c = c.replace("\n", "")
        ar = c.split("\t")
        res = print_tc(ar)
        print("s: %s, k: %d" %(res[0], res[1]))
        print("%sENDRES" %(res[2]))
