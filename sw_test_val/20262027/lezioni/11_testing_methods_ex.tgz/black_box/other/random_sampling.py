import sys
import math
import random
import string

SPACES_EVERY = 10

def random_str(dim):
    res = ""
    for i in range(dim):
        if random.randint(0, SPACES_EVERY - 1) == 0:
            res += random.choice(list(string.whitespace))
        else:
            res += random.choice(list(string.ascii_letters))
    return res

if (len(sys.argv) < 4):
    print("Please provide T, t and the multiplication factor for S'")
    sys.exit(1)
R = int(float(sys.argv[1])/float(sys.argv[2]))
S = int(R**(1.0/3))
Sp = int(sys.argv[3])*int(R**(1.0/3))
print("R:%d\tS:%d\tSp:%d\tS^3:%d\tSp^3:%d" %(R, S, Sp, S**3, Sp**3))
min_int = -2**63
max_int = 2**63
l_int = (max_int - min_int)/(Sp - 1)
min_float = -1.7E30
max_float = 1.7E30
l_float = (max_float - min_float)/(Sp - 1)
max_str_dim = 100
if sys.argv[3] == "1":
    for tupl in range(S**3):
        res_tupl = tupl
        i = min_int + (res_tupl%S)*l_int
        res_tupl //= S
        j = min_float + (res_tupl%S)*l_float
        res_tupl //= S
        s = random_str(res_tupl%S)
        print("num:%d\t\ti:%d\tf:%le\ts:%s" %(tupl, i, j, s))
else:
    overall = []
    for tupl in range(Sp**3):
        res_tupl = tupl
        i = min_int + (res_tupl%Sp)*l_int
        res_tupl //= Sp
        j = min_float + (res_tupl%Sp)*l_float
        res_tupl //= Sp
        s = random_str(res_tupl%Sp)
        overall += [(i, j, s)]
    for k in range(S**3):
        p = random.choice(range(len(overall)))
        (i, j, s) = overall.pop(p)
        print("num:%d\t\ti:%d\tf:%le\ts:%s" %(k, i, j, s))
    
