import sys
import random
import string
import re
import math

SMALL_VAL = 1e-10
MAX_EXP = 9
MIN_DELTA_VAL = 1
MAX_DELTA_VAL = 10
VERY_BIG_INT = 2**20

def read_par(ar):
    if ar[0] == "spec":
        if ar[2] == "nan":
            return "Math.sqrt(-1)"
        if ar[2] == "minval":
            return "Double.MIN_VALUE"
        if ar[2] == "maxval":
            return "Double.MAX_VALUE"
        if ar[2] == "minnorm":
            return "Double.MIN_NORMAL"
        if ar[2] == "posinf":
            return "1.0/0.0"
        if ar[2] == "neginf":
            return "-1.0/0.0"
    elif ar[0] == "0":
        return 0
    elif ar[0][1] == "t": #<-100 or > 100
        if ar[1] == "float":
            mant = random.uniform(1, 2)
            expon = random.randint(2, MAX_EXP)
            return mant*(10**expon)*(1 if ar[0][0] == "g" else -1)
        return random.randint(101, VERY_BIG_INT)*(1 if ar[0][0] == "g" else -1)
    else:
        if ar[1] == "float":
            return random.uniform(float(ar[0].split("_")[0]) + SMALL_VAL, float(ar[0].split("_")[1]) - SMALL_VAL)
        return random.randint(int(ar[0].split("_")[0]) + 1, int(ar[0].split("_")[1]) - 1)

def adj_with_delta(ar, a, b, c):
    curr = b*b - 4*a*c
    if (curr == 0 and ar == "0") or (curr > 0 and ar == "gt_0") or (curr < 0 and ar == "lt_0"):
        return (a, b, c)
    #all zeros already present; easiest way is to change b only
    #b^2 - 4ac = 0; b = sqrt(4*a*c)
    return (a, math.sqrt(4*a*c*(1 if a*c >= 0 else -1)) + (0 if ar == "0" else (-1 if ar == "lt_0" else 1))*random.uniform(MIN_DELTA_VAL, MAX_DELTA_VAL), c)

def print_tc(ar):
    a = read_par(ar[0:3])
    b = read_par(ar[3:6])
    c = read_par(ar[6:9])
    if not(type(a) is str or type(b) is str or type(c) is str):
        (a, b, c) = adj_with_delta(ar[9], a, b, c)
    return (a, b, c)

if (len(sys.argv) != 2):
    print("Provide the file with the combinations")
else:
    f = open(sys.argv[1], "r")
    content = f.readlines()
    f.close()
    for c in content[1:]:
        c = c.replace("\n", "")
        ar = c.split("\t")
        res = print_tc(ar)
        print("a: %s, b: %s, c: %s" %(str(res[0]), str(res[1]), str(res[2])))
