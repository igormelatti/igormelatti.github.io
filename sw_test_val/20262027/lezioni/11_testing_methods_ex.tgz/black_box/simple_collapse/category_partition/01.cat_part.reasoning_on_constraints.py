import sys
import re

def first_reversing(full_len):
    # first = True
    for spaces_num in range(full_len + 1):
        j = 0
        working = ""
        while j < spaces_num and len(working) < full_len:
            cons_sp = min(2, spaces_num - j)
            cons_sp = min(cons_sp, full_len - len(working) - 1)
            working += " "*cons_sp
            working += "0"
            j += cons_sp
        working += "0"*(full_len - len(working) if len(working) < full_len else 0)
        while j < spaces_num:
            # if (first):
            #     return (spaces_num)
            #     first = False
            working = working[ : working.rfind("0")] + " " + working[working.rfind("0") + 1 : ]
            j += 1
        # print(working)
        # print("slen = %d, space_num = %d, occ_cons_spaces = %d" %(full_len, spaces_num, len(re.findall('  +', working))))
        res = len(re.findall('  +', working))
        if (spaces_num == 0):
            old = res
        else:
            if (old > res):
                return (old, spaces_num - 1)
            old = res

def formula(length, spaces):
    A = (length + (1 if length%3 == 2 else 0))//3
    B = 2*A + (length + 1)%3
    if spaces < B:
        return spaces//2
    return A - (spaces - B)
            
def print_all(full_len):
    for spaces_num in range(full_len + 1):
        j = 0
        working = ""
        while j < spaces_num and len(working) < full_len:
            cons_sp = min(2, spaces_num - j)
            cons_sp = min(cons_sp, full_len - len(working) - 1)
            working += " "*cons_sp
            working += "0"
            j += cons_sp
        working += "0"*(full_len - len(working) if len(working) < full_len else 0)
        while j < spaces_num:
            working = working[ : working.rfind("0")] + " " + working[working.rfind("0") + 1 : ]
            j += 1
        print(working)
        print("slen = %d, space_num = %d, occ_cons_spaces = %d vs %d" %(full_len, spaces_num, len(re.findall('  +', working)), formula(full_len, spaces_num)))

if (not(len(sys.argv) in [2, 3])):
    print("Please provide the min and max len of the string, or the len of the string")
    sys.exit(1)
if (len(sys.argv) == 3):
    for i in range(int(sys.argv[1]), int(sys.argv[2])):
        res = first_reversing(i)
        print("%d --> %d, %d" %(i, res[0], res[1]))
else:
    print_all(int(sys.argv[1]))
