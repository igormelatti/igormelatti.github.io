python3 04.write_tc.py 02.combine.res.txt | tee 04.res.txt
