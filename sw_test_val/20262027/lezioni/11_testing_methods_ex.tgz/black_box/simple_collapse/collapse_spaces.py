import sys
import random
import string

def sumS(S, j = None):
    s = 0
    for (i, k) in S:
        if j == None or i < j: 
            s += k - 1
    return s

def sigma(S, j):
    return sumS(S, j)

def collapse_spaces(s):
    S = []
    Sp = []
    accum = 0
    for i in range(len(s)):
        if s[i] == " " and s[i - 1] != " ":
            k = 1
            for j in range(i + 1, len(s)):
                if s[j] == " ":
                    k += 1
                else:
                    break
            if k > 1:
                S += [(i, k)]
                Sp += [(i - accum, k)]
                accum += k - 1
    res = ""
    for j in range(len(s) - sumS(S)):
        res += s[j + sigma(Sp, j)]
    return res

def gen_input_string_ext_aux(S, cs_every, min_cs, max_cs):
    ret = ""
    for i in range(len(S)):
        ret += S[i]
        if (S[i] == " "):
            if random.randint(1, cs_every) == 1:
                ret += " "*(random.randint(min_cs, max_cs) - 1)
    return ret

def gen_input_string_ext(namefile, min_l, max_l, cs_every, min_cs, max_cs):
    f = open(namefile, "r")
    S = f.read()
    f.close()
    i = random.randint(0, len(S))
    j = min(random.randint(min_l, max_l) + i, len(S))
    return gen_input_string_ext_aux(S[i:j], cs_every, min_cs, max_cs)

def gen_input_string(min_l, max_l, cs_every, min_cs, max_cs):
    ret = ""
    l = random.randint(min_l, max_l)
    for i in range(l):
        if random.randint(1, cs_every) == 1:
            ret += " "*random.randint(min_cs, max_cs)
        else:
            # ret += random.sample(list(string.printable), 1)[0]
            ret += random.sample(list(string.ascii_letters + " "), 1)[0]
    return ret

def gen_input_string_slide(exit_prob_s0, space_prob_s0, char_prob_s0, exit_prob_s1, space_prob_s1, multispace_prob_s1):
    ret = ""
    state = "s0"
    while (True):
        if state == "s0":
            r = random.randint(1, exit_prob_s0 + space_prob_s0 + char_prob_s0)
            if r <= exit_prob_s0:
                break
            elif r <= exit_prob_s0 + space_prob_s0:
                ret += " "
                state = "s1"
            else:
                ret += random.sample(list(string.ascii_letters + " "), 1)[0]
        else:
            r = random.randint(1, exit_prob_s1 + space_prob_s1 + multispace_prob_s1)
            if r <= exit_prob_s1:
                break
            elif r <= exit_prob_s1 + multispace_prob_s1:
                ret += " "
            else:
                ret += " "
                state = "s0"
    return ret
                

if len(sys.argv) == 2:
    print(collapse_spaces(sys.argv[1]))
elif len(sys.argv) == 6:
    ret = gen_input_string(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]))
    print(ret)
    print(collapse_spaces(ret))
elif len(sys.argv) == 8:
    ret = gen_input_string_ext(sys.argv[1], int(sys.argv[1 + 1]), int(sys.argv[2 + 1]), int(sys.argv[3 + 1]), int(sys.argv[4 + 1]), int(sys.argv[5 + 1]))
    print(ret)
    print(collapse_spaces(ret))
elif len(sys.argv) == 7:
    ret = gen_input_string_slide(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]))
    print(ret)
    print(collapse_spaces(ret))
else:
    print("Either one argument (as the string to be collapsed), or 5 (minimum and maximum length, probability of consecutive spaces as 1/x if x is given, minimum and maximum consecutive spaces), or 7 (name of a text file with long text, minimum and maximum length, probability of consecutive spaces as 1/x if x is given, minimum and maximum consecutive spaces, any input), or 6 (probability of s0->s2, probability of s0->s1, probability of s0->s0, probability of s1->s2, probability of s1->s0, probability of s1->s1, all as x/sum_other_same_state if x is given)")
