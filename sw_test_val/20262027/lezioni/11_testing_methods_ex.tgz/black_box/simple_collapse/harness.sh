if [ $# -lt 1 ]
then
    input_file=category_partition/04.res.txt
else
    input_file=$1
fi

javac Driver.java || { echo Unable to compile; exit; }
IFS=$'\n'
i=0
j=1
for line in `cat $input_file`
do
    if [ $i -eq 0 ]
    then
	#strip "ENDTEST" at the end
	input_str=${line:0:-7}
    else
	exp_res=${line:0:-6}
	res=`java Driver "$input_str"`
	if [ "$res" != "$exp_res" ]
	then
	    echo ERROR on input:
	    echo "$input_str"
	    echo expected result:
	    echo "$exp_res"
	    echo actual result:
	    echo "$res"
	    exit
	else
	    echo OK for line $j
	    ((j++))
	fi
    fi
    i=$(((i + 1)%2))
done

