class B extends S
{
    private int c;
    public B(int v) {
	a = v;
    }
}
