class S
{
    protected int a, b;

    public void make_something() {
	if (a == 1)
	    a = 2;
    }

    public void make_something(int v) {
	if (a == v)
	    a = 2;
    }
}
