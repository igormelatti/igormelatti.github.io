package com.mycompany.app;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

// import org.junit.Test;
// import org.junit.Before;
// import org.junit.jupiter.params.ParameterizedTest;
// import org.junit.jupiter.params.provider.CsvFileSource;
// import org.junit.jupiter.params.provider.CsvSource;
// import org.junit.jupiter.params.provider.ValueSource;
// import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest {
    public static App cs;

    @BeforeAll
    public static void setUp() {
	cs = new App();
    }
    
    @Test
    public void T1() {
	App cs = new App();
    	String res = cs.collapseSpaces("ciao  ciao");
        assertTrue(res.equals("ciao ciao"));
    }
    
    @Test
    public void T2() {
	App cs = new App();
    	String res = cs.collapseSpaces("ciao ciao");
        assertTrue(res.equals("ciao ciao"));
    }

    //ignored, see https://www.baeldung.com/parameterized-tests-junit-5
    @ParameterizedTest
    @CsvFileSource(resources = "/input.csv")
    public void Many(String in, String out) {
	App cs = new App();
    	String res = cs.collapseSpaces(in);
    	// String res = cs.collapseSpacesCorr(in);
        assertTrue(res.equals(out));
    }
}
