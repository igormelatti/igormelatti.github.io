mvn clean test
