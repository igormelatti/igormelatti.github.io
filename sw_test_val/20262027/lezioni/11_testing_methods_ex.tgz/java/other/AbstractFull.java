public abstract class AbstractFull {
    protected int i_prot;
    private int i_priv;
    public int i_pub;
    // constructor cannot be abstract
    // public AbstractFull(int i1, int i2, int i3) {
    // 	i_prot = i1;
    // 	i_priv = i2;
    // 	i_pub = i3;
    // }
    public abstract int fun1();
    protected abstract void fun2();
    // abstract methods cannot be private
    // private abstract void fun3();
}
