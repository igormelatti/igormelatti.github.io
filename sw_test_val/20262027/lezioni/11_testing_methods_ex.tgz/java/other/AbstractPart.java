// must be abstract if at least one is abstract
// can be abstract also if none is abstract
public abstract class AbstractPart {
    protected int i_prot;
    private int i_priv;
    public int i_pub;
    public AbstractPart(int i1, int i2, int i3) {
	i_prot = i1;
	i_priv = i2;
	i_pub = i3;
    }
    public void fun1() {
	System.out.println("Hello " + i_priv);
    }
    protected abstract void fun2();
}
