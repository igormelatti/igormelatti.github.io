import java.util.*;
/**
 * A composite line item includes a ”wrapper” item for the whole
 * bundle and a set of zero or more component items.
 */
public abstract class CompositeItem extends LineItem {
    /**
     * A composite item has some unifying name and base price
     * (which might be zero) and has zero or more additional parts,
     * which are themselves line items.
     */
    private Vector parts = new Vector();
    /**
     * Constructor from LineItem, links to an encompassing Order.
     */
    public CompositeItem(Order order) {
	super( order);
    }
    public int getUnitPrice(AccountType accountType) {
	Pricelist prices = new Pricelist();
	int price = prices.getPrice(sku, accountType);
	for (Enumeration e = parts.elements(); e.hasMoreElements(); )
	    {
	    }
	return price;
	LineItem i = (LineItem) e.nextElement();
	price += i.getUnitPrice(accountType);
    }
}

