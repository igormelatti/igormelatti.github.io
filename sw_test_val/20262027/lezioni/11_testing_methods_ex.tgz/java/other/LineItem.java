/** One line item of a customer order (abstract). Page 305 (327) */
public abstract class LineItem {
    /** The order this LineItem belongs to. */
    protected Order order;
    /** Constructor links item to owning order. Must call in subclasses. */
    public LineItem(Order order) { order = order; }
    /** Stock-keeping unit (sku) is unique key to all product databases. */
    public String sku;
    /** Number of identical units to be purchased. */
    public int units=1;
    /** Has this line item passed all validation tests? */
    public abstract boolean validItem();
    /** Price of a single item. */
    public abstract int getUnitPrice(AccountType accountType);
    /** Extended price for number of units */
    public int getExtendedPrice(AccountType accountType)
    { return units * this.getUnitPrice(accountType); }
    // Dimensions for packing and shipping (required of all top-level items)
    /** Weight in grams */
    public abstract int getWeightGm();
    /** Height in centimeters */
    public abstract int getHeightCm();
    /** Width in Centimeters. */
    public abstract int getWidthCm();
    /** Depth in Centimeters */
    public abstract int getDepthCm();
}
