public class UseFull {
    AbstractFull ab;
    public UseFull() {
	// no, it is abstract
	// ab = new AbstractFull();
	// but no problem with this!!!
	ab.fun1();
    }
}
