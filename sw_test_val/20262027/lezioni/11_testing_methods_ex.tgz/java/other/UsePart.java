public class UsePart {
    AbstractPart ab;
    public UsePart() {
	// no, it is abstract
	ab = new AbstractPart();
	// but no problem with this!!!
	ab.fun1();
    }
}
