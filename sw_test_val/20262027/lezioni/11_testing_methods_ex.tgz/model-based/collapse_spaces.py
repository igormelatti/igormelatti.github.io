import sys
import random
import string

def sumS(S, j = None):
    s = 0
    for (i, k) in S:
        if j == None or i < j: 
            s += k - 1
    return s

def sigma(S, j):
    return sumS(S, j)

def collapse_spaces(s):
    S = []
    Sp = []
    accum = 0
    for i in range(len(s)):
        if s[i] == " " and s[i - 1] != " ":
            k = 1
            for j in range(i + 1, len(s)):
                if s[j] == " ":
                    k += 1
                else:
                    break
            if k > 1:
                S += [(i, k)]
                Sp += [(i - accum, k)]
                accum += k - 1
    res = ""
    for j in range(len(s) - sumS(S)):
        res += s[j + sigma(Sp, j)]
    return res

def gen_input_string_slide(exit_prob_s0, space_prob_s0, char_prob_s0, exit_prob_s1, space_prob_s1, multispace_prob_s1):
    ret = ""
    state = "s0"
    while (True):
        if state == "s0":
            r = random.randint(1, exit_prob_s0 + space_prob_s0 + char_prob_s0)
            if r <= exit_prob_s0:
                break
            elif r <= exit_prob_s0 + space_prob_s0:
                ret += " "
                state = "s1"
            else:
                ret += random.choice(list(string.ascii_letters + " "))
        else:
            r = random.randint(1, exit_prob_s1 + space_prob_s1 + multispace_prob_s1)
            if r <= exit_prob_s1:
                break
            elif r <= exit_prob_s1 + multispace_prob_s1:
                ret += " "
            else:
                ret += " "
                state = "s0"
    return ret
                
if len(sys.argv) == 7:
    ret = gen_input_string_slide(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]))
    print(ret)
    print(collapse_spaces(ret))
else:
    print("Please provide 6 arguments: probability of s0->s2, probability of s0->s1, probability of s0->s0, probability of s1->s2, probability of s1->s0, probability of s1->s1, all as x/sum_other_same_state if x is given")
