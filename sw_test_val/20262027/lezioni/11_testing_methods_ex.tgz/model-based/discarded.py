
def grammar2graph(G):
    res = {}
    for k in G.keys():
        if k == 0:
            continue
        if k not in res:
            res[k] = []
        for i in range(len(G[k])):
            res[k] += [(G[k][i]["prob"], G[k][i]["prods"])]
    return res

def single_trans_path_cover(G, start):
    stack = [[start, 0]]
    stack_s = set()
    visited = set()
    paths = []
    while len(stack) > 0:
        (curr_s, curr_i) = stack[-1]
        if curr_i == len(G[curr_s]):
            stack = stack[:-1]
            if stack != []:
                stack_s.remove((stack[-1][0], curr_s))
        else:
            next_s = str(G[curr_s][curr_i][1])
            stack[-1][1] += 1
            if (curr_s, next_s) not in visited:
                visited.add((curr_s, next_s))
                stack += [[next_s, 0]]
                stack_s.add((curr_s, next_s))
            else:
                res = []
                for (s, i) in stack:
                    res += [s]
                if (curr_s, next_s) not in stack_s:
                    res += [next_s]
                paths += [res]
    res = []
    for i in range(len(paths)):
        ok = True
        for j in range(len(paths)):
            if j == i:
                continue
            if len(paths[i]) < len(paths[j]):
                if paths[i] == paths[j][:len(paths[i])]:
                    ok = False
        if ok:
            res += [paths[i]]
    return res
