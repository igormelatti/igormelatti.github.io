def check_t_cover(tcover):
    execd = set()
    for t in tcover:
        for i in range(len(t) - 1):
            if ((t[i], t[i + 1]) not in trans):
                print("ERROR: "+ str((t[i], t[i + 1])))
            execd.add((t[i], t[i + 1]))
    print("Coverage: " + str(len(execd)/len(trans)))
    for (i, j) in set(trans).difference(execd):
        print(i, j)

def output_t_cover(trans, start):
    nodes = list(set([t[0] for t in trans]).union(set([t[1] for t in trans])))
    G = {}
    for t in trans:
        if t[0] not in G:
            G[t[0]] = []
        G[t[0]] += [t[1]]
    for n in nodes:
        if n not in G:
            G[n] = []
    stack = [[start, 0]]
    stack_s = set([start])
    visited = set([start])
    while len(stack) > 0:
        (curr_s, curr_i) = stack[-1]
        if curr_i == len(G[curr_s]):
            stack = stack[:-1]
            stack_s.remove(curr_s)
        else:
            next_s = G[curr_s][curr_i]
            stack[-1][1] += 1
            if next_s not in visited:
                visited.add(next_s)
                stack += [[next_s, 0]]
                stack_s.add(next_s)
            else:
                res = ""
                for (s, i) in stack:
                    res += str(s) + " "
                res += str(next_s)
                print(res)

def output_single_path_cover(trans, start):
    nodes = list(set([t[0] for t in trans]).union(set([t[1] for t in trans])))
    G = {}
    for t in trans:
        if t[0] not in G:
            G[t[0]] = []
        G[t[0]] += [t[1]]
    for n in nodes:
        if n not in G:
            G[n] = []
    stack = [[start, 0]]
    stack_s = set([start])
    visited = set([start])
    paths = []
    while len(stack) > 0:
        (curr_s, curr_i) = stack[-1]
        if curr_i == len(G[curr_s]):
            stack = stack[:-1]
            stack_s.remove(curr_s)
        else:
            next_s = G[curr_s][curr_i]
            stack[-1][1] += 1
            if next_s not in visited:
                visited.add(next_s)
                stack += [[next_s, 0]]
                stack_s.add(next_s)
            else:
                res = []
                for (s, i) in stack:
                    res += [s]
                if next_s not in stack_s:
                    res += [next_s]
                paths += [res]
    res = []
    for i in range(len(paths)):
        ok = True
        for j in range(len(paths)):
            if j == i:
                continue
            if len(paths[i]) < len(paths[j]):
                if paths[i] == paths[j][:len(paths[i])]:
                    ok = False
        if ok:
            res += [paths[i]]
    for r in res:
        print(r)

def output_single_trans_path_cover(trans, start):
    nodes = list(set([t[0] for t in trans]).union(set([t[1] for t in trans])))
    G = {}
    for t in trans:
        if t[0] not in G:
            G[t[0]] = []
        G[t[0]] += [t[1]]
    for n in nodes:
        if n not in G:
            G[n] = []
    stack = [[start, 0]]
    stack_s = set()
    visited = set()
    paths = []
    while len(stack) > 0:
        (curr_s, curr_i) = stack[-1]
        if curr_i == len(G[curr_s]):
            stack = stack[:-1]
            if stack != []:
                stack_s.remove((stack[-1][0], curr_s))
        else:
            next_s = G[curr_s][curr_i]
            stack[-1][1] += 1
            if (curr_s, next_s) not in visited:
                visited.add((curr_s, next_s))
                stack += [[next_s, 0]]
                stack_s.add((curr_s, next_s))
            else:
                res = []
                for (s, i) in stack:
                    res += [s]
                if (curr_s, next_s) not in stack_s:
                    res += [next_s]
                paths += [res]
    res = []
    for i in range(len(paths)):
        ok = True
        for j in range(len(paths)):
            if j == i:
                continue
            if len(paths[i]) < len(paths[j]):
                if paths[i] == paths[j][:len(paths[i])]:
                    ok = False
        if ok:
            res += [paths[i]]
    for r in res:
        print(r)

def output_interior_loop_cover(trans, start, kmin, kmax):
    nodes = list(set([t[0] for t in trans]).union(set([t[1] for t in trans])))
    G = {}
    for t in trans:
        if t[0] not in G:
            G[t[0]] = []
        G[t[0]] += [t[1]]
    for n in nodes:
        if n not in G:
            G[n] = []
    stack = [[start, 0]]
    stack_s = set()
    visited = set()
    paths = []
    while len(stack) > 0:
        (curr_s, curr_i) = stack[-1]
        if curr_i == len(G[curr_s]):
            stack = stack[:-1]
            if stack != []:
                stack_s.remove((stack[-1][0], curr_s))
        else:
            next_s = G[curr_s][curr_i]
            stack[-1][1] += 1
            if (curr_s, next_s) not in visited:
                visited.add((curr_s, next_s))
                stack += [[next_s, 0]]
                stack_s.add((curr_s, next_s))
            else:
                res = []
                for (s, i) in stack:
                    res += [s]
                res += [next_s]
                paths += [res]
    res = []
    for i in range(len(paths)):
        ok = True
        for j in range(len(paths)):
            if j == i:
                continue
            if len(paths[i]) < len(paths[j]):
                if paths[i] == paths[j][:len(paths[i])]:
                    ok = False
        if ok:
            res += [paths[i]]
    very_res = []
    kinterm = (kmin + kmax)//2
    for r in res:
        for i in range(len(r) - 1):
            if r[i] == r[-2] and r[i + 1] == r[-1]:
                break
        very_res += [r[:i] + (r[i:]*kmin)]
        very_res += [r[:i] + (r[i:]*kinterm)]
        very_res += [r[:i] + (r[i:]*kmax)]
    for r in very_res:
        print(r)
                
trans = [(0, 2), (0, 3), (0, 5), (2, 4), (4, 1), (4, 5), (1, 0), (3, 5), (5, 2), (5, 6), (5, 7), (5, 8), (6, 0), (7, 8), (7, 9), (7, 5), (8, 6), (8, 9), (8, 7), (9, 7), (5, 9), (9, 6)]
#print("Number of transitions: " + str(len(trans)))
#check_t_cover([[0, 2, 4, 1, 0], [0, 5, 2, 4, 5, 6, 0], [0, 3, 5, 9, 6, 0], [0, 3, 5, 7, 5, 8, 7, 8, 9, 7, 9, 6, 0]])
print("Complete transition cover")
output_t_cover(trans, 0)
print("Complete single-path cover")
output_single_path_cover(trans, 0)
print("Complete single-transition-path cover")
output_single_trans_path_cover(trans, 0)
print("Complete interior-bounded-loop cover")
output_interior_loop_cover(trans, 0, 2, 5)
