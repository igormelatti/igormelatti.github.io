import random

MAX_PROD = 100

G1 = {
    0: "search",
    "search": [
        {"min": 0, "max": MAX_PROD, "name": "S1", "prob": 1/3, "prods": ["search", "binop", "term"]},
        {"min": 0, "max": MAX_PROD, "name": "S2", "prob": 1/3, "prods": ["not", "search"]},
        {"min": 0, "max": MAX_PROD, "name": "S3", "prob": 1/3, "prods": ["term"]}
    ],
    "binop": [
        {"min": 0, "max": MAX_PROD, "name": "B1", "prob": 1/2, "prods": ["and"]},
        {"min": 0, "max": MAX_PROD, "name": "B2", "prob": 1/2, "prods": ["or"]}
    ],
    "term": [
        {"min": 0, "max": MAX_PROD, "name": "T1", "prob": 1/2, "prods": ["regexp"]},
        {"min": 0, "max": MAX_PROD, "name": "T2", "prob": 1/2, "prods": ["(", "search", ")"]}
    ],
    "regexp": [
        {"min": 0, "max": MAX_PROD, "name": "R1", "prob": 1/4, "prods": ["char", "regexp"]},
        {"min": 0, "max": MAX_PROD, "name": "R2", "prob": 1/4, "prods": ["char"]},
        {"min": 0, "max": MAX_PROD, "name": "R3", "prob": 1/4, "prods": ["{", "choices", "}"]},
        {"min": 0, "max": MAX_PROD, "name": "R4", "prob": 1/4, "prods": ["*"]}
    ],
    "choices": [
        {"min": 0, "max": MAX_PROD, "name": "C1", "prob": 1/2, "prods": ["regexp"]},
        {"min": 0, "max": MAX_PROD, "name": "C2", "prob": 1/2, "prods": ["regexp", ",", "regexp"]}
    ]
}

G2 = {
    0: "Model",
    "Model": [
        {"min": 0, "max": MAX_PROD, "name": "Model", "prob": 1, "prods": ["modelNumber", "compSequence", "optCompSequence"]},
    ],
    "compSequence": [
        {"min": 0, "max": 16, "name": "compSeq1", "prob": 1/2, "prods": ["Component", "compSequence"]},
        {"min": 0, "max": MAX_PROD, "name": "compSeq2", "prob": 1/2, "prods": ["empty"]}
    ],
    "optCompSequence": [
        {"min": 0, "max": 16, "name": "optCompSeq1", "prob": 1/2, "prods": ["optionalComponent", "optCompSequence"]},
        {"min": 0, "max": MAX_PROD, "name": "optCompSeq2", "prob": 1/2, "prods": ["empty"]}
    ],
    "Component": [
        {"min": 0, "max": MAX_PROD, "name": "Comp", "prob": 1, "prods": ["ComponentType", "ComponentValue"]},
    ],
    "OptionalComponent": [
        {"min": 0, "max": MAX_PROD, "name": "OptComp", "prob": 1, "prods": ["ComponentType"]},
    ],
    "modelNumber": [
        {"min": 0, "max": MAX_PROD, "name": "modNum", "prob": 1, "prods": ["string"]},
    ],
    "ComponentType": [
        {"min": 0, "max": MAX_PROD, "name": "CompTyp", "prob": 1, "prods": ["string"]},
    ],
    "ComponentValue": [
        {"min": 0, "max": MAX_PROD, "name": "CompVal", "prob": 1, "prods": ["string"]},
    ]
}

def random_walk(G):
    curr = [G[0]]
    al1 = True
    while al1:
        al1 = False
        for i in range(len(curr)):
            if curr[i] in G: #non-terminal
                selected = random.randint(0, len(G[curr[i]]) - 1)
                curr = curr[:i] + [p for p in G[curr[i]][selected]["prods"]] + curr[i + 1:]
                al1 = True
    return curr
                
print(random_walk(G1))
