#NOT CORRECT AND NOT COMPLETED, TO BE RECONSIDERED

slide149 = [
    [1, -1, -1, -1, -1, -1, 0, -1, -1],
    [1, -1, -1, -1, -1, -1, 1, -1, -1],
    [0, 0, 0, -1, -1, -1, 0, -1, -1],
    [0, 0, 0, -1, -1, -1, 1, -1, -1],
    [0, 0, 1, -1, 0, -1, -1, 0, -1],
    [0, 0, 1, -1, 0, -1, -1, 1, -1],
    [0, 0, -1, -1, 1, -1, -1, -1, 0],
    [0, 0, -1, -1, 1, -1, -1, -1, 1],
    [-1, 1, 0, 0, -1, -1, 0, -1, -1],
    [-1, 1, 0, 0, -1, -1, 1, -1, -1],
    [-1, 1, 1, 0, 0, -1, -1, 0, -1],
    [-1, 1, 1, 0, 0, -1, -1, 1, -1],
    [-1, 1, 0, 1, -1, 0, -1, 0, -1],
    [-1, 1, 0, 1, -1, 0, -1, 1, -1],
    [-1, 1, 1, 1, -1, -1, -1, -1, 0],
    [-1, 1, 1, 1, -1, -1, -1, -1, 1],
    [-1, 1, -1, -1, 1, -1, -1, -1, 0],
    [-1, 1, -1, -1, 1, -1, -1, -1, 1],
    [-1, 1, -1, -1, -1, 1, -1, -1, 0],
    [-1, 1, -1, -1, -1, 1, -1, -1, 1],
]

slide149_res = ["Edu", "SP", "ND", "SP", "T1", "SP", "T2", "SP", "ND", "SP", "T1", "SP", "T1", "SP", "T2", "SP", "T2", "SP", "T2", "SP"]

at_most_one_ind = ((True, 0, True, 1), (False, 3, True, 5), (False, 2, True, 4), (False, 7, True, 8))

implications_ind = ((True, 5, True, 3), (True, 4, True, 2), (True, 8, True, 7))

def check_amo(line, amo):
    for (aa, a, ba, b) in amo: #implied by an incorrect column
        if line[a] != -1 and line[b] != -1:
            with_neg_a = line[a] if aa else 1 - line[a]
            with_neg_b = line[b] if ba else 1 - line[b]
            if with_neg_a + with_neg_b > 1:
                return False
    return True

def check_impl(line, impl):
    for (aa, a, ba, b) in impl: #implied by an incorrect column
        if line[a] != -1 and line[b] != -1:
            with_neg_a = line[a] if aa else 1 - line[a]
            with_neg_b = line[b] if ba else 1 - line[b]
            if with_neg_a == 1 and with_neg_b == 0:
                return False
    return True

def implied(line, t, amo, impl):
    nodc = []
    for i in range(len(t)):
        if line[i] != -1 and t[i] != -1 and line[i] != t[i]: #easy case, they are really different
            return False
        if line[i] != -1:
            nodc += [line[i]] #the other is either dc or the same
        elif t[i] != -1:
            nodc += [t[i]]
        else:
            nodc += [-1]
    if not(check_amo(nodc, amo)):
        return False
    if not(check_impl(nodc, impl)):
        return False
    return True

def present(line, excl, T, amo, impl):
    for iT in range(len(T)):
        t = T[iT]
        if (t == excl):
            continue
        assert(len(line) == len(t))
        if implied(line, t, amo, impl):
            # print("Implied by " + str(t))
            return iT
    return None

def generate_new_cols(T, T_res, amo, impl):
    additional = []
    additional_res = []
    for iT in range(len(T)):
        t = T[iT]
        pos = []
        for i in range(len(t)):
            if t[i] != -1:
                pos += [i]
        assert(pos != []) #exclude don't cares only, should never be present
        for p in pos:
            new_line = t[0 : p] + [1 - t[p]] + t[(p + 1) : ]
            if not(check_amo(new_line, amo)) or not(check_impl(new_line, impl)):
                continue
            # print(t, new_line)
            where = present(new_line, t, T + additional, amo, impl)
            if where == None:
                additional += [new_line]
                additional_res += ["ERR"]
            else:
                if where < len(T):
                    tbm = T[where]
                else:
                    tbm = additional[len(T) - where]
                for j in range(len(tbm)):
                    if t[j] != -1 and tbm[j] == -1:
                        tbm[j] = t[j]
    return (T + additional, T_res + additional_res)

def simplify(T, T_res):
    for i in range(len(T)):
        for j in range(len(T)):
            if i == j or T_res[i] != T_res[j]:
                continue
            diffs_tot = []
            diffs_dc = []
            for k in range(len(T[i])):
                if (T[i][k], T[j][k]) in [(0, 1), (1, 0)]:
                    diffs_tot += [k]
                elif (T[i][k], T[j][k]) in [(0, -1), (1, -1), (-1, 0), (-1, 1)]:
                # elif (T[i][k], T[j][k]) in [(0, 1), (0, -1), (1, 0), (1, -1), (-1, 0), (-1, 1)]:
                    diffs_dc += [k]
                if len(diffs_tot) == 1:
                    diffs_dc += diffs_tot
                
            

def expand(T, amo, impl):
    ret = []
    for iT in range(len(T)):
        t = T[iT]
        for (aa, a, ba, b) in amo:
            if t[a] != -1 and t[b] != -1:
                with_neg_a = t[a] if aa else 1 - t[a]
                with_neg_b = t[b] if ba else 1 - t[b]
                if with_neg_a + with_neg_b > 1:
                    print("ERROR AMO: " + str(t, aa, a, ba, b))
                    return []
            elif (t[a] != -1 and t[b] == -1) or (t[a] == -1 and t[b] != -1):
                ret += [t[:]]
                change = (b, ba, a, aa) if (t[a] != -1 and t[b] == -1) else (a, aa, b, ba)
                ret[-1][change[0]] = 0 if change[1] else 1
                if not(((t[change[2]] == 1 and change[3]) or (t[change[2]] == 0 and not(change[3])))):
                    ret += [t[:]]
                    ret[-1][change[0]] = 1 if change[1] else 0
                # if ((t[a] == 1 and aa) or (t[a] == 0 and not(aa))):
                #     ret[-1][b] = 0 if ba else 1
                # else:
                #     amo_other += [(2, iT, aa, a, ba, b)]
            else: #both don't care; ALSO ORGANIZE THIS IN THE SAME WAY
                if aa and ba:
                    values = ((0, 0), (0, 1), (1, 0))
                elif aa and not(ba):
                    values = ((0, 0), (0, 1), (1, 1))
                elif not(aa) and ba:
                    values = ((0, 0), (1, 0), (1, 1))
                else:
                    values = ((0, 1), (1, 0), (1, 1))
                for i in range(len(values)):
                    ret += [t[:]]
                    ret[-1][a] = v1
                    ret[-1][b] = v2
        for (aa, a, ba, b) in impl: #TO BE COMPLETED!
            if t[a] != -1 and t[b] != -1:
                with_neg_a = t[a] if aa else 1 - t[a]
                with_neg_b = t[b] if ba else 1 - t[b]
                if with_neg_a == 1 and with_neg_b == 0:
                    print("ERROR IMPL: " + str(t, aa, a, ba, b))
                    return []
            elif (t[a] != -1 and t[b] == -1) or (t[a] == -1 and t[b] != -1):
                ret += [t[:]]
                change = (b, ba, a, aa) if (t[a] != -1 and t[b] == -1) else (a, aa, b, ba)
                ret[-1][change[0]] = 1 if change[1] else 1
                if not(((t[change[2]] == 1 and change[3]) or (t[change[2]] == 0 and not(change[3])))):
                    ret += [t[:]]
                    ret[-1][change[0]] = 1 if change[1] else 0
            else: #both don't care
                if aa and ba:
                    values = ((0, 0), (0, 1), (1, 0))
                elif aa and not(ba):
                    values = ((0, 0), (0, 1), (1, 1))
                elif not(aa) and ba:
                    values = ((0, 0), (1, 0), (1, 1))
                else:
                    values = ((0, 1), (1, 0), (1, 1))
                for i in range(len(values)):
                    ret += [t[:]]
                    ret[-1][a] = v1
                    ret[-1][b] = v2
    return ret

print(generate_new_cols(slide149, slide149_res, at_most_one_ind, implications_ind))
