cbmc uav.c --cover mcdc --unwind 6 --xml-ui > res.xml
