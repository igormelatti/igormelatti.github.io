class collapse_spaces {
    /**
     * Remove/collapse multiple spaces.
     *
     * @param String string to remove multiple spaces from.
     * @return String
     */
    public static String collapseSpaces(String argStr)
    {
	char last = argStr.charAt(0);
	StringBuffer argBuf = new StringBuffer();
	for (int cIdx = 0 ; cIdx < argStr.length(); cIdx++) {
	    char ch = argStr.charAt(cIdx);
	    if (ch != ' ' || last != ' ') {
		argBuf.append(ch);
		last = ch;
	    }
	}
	return argBuf.toString();
    }
    static java.util.Set<String> statements = new java.util.HashSet<String>();
    public static String collapseSpacesInstr(String argStr)
    {
	statements.add("1");
	char last = argStr.charAt(0);
	statements.add("2");
	StringBuffer argBuf = new StringBuffer();
	statements.add("3");
	int cIdx = 0;
	statements.add("4");
	while (cIdx < argStr.length()) {
	    statements.add("5");
	    char ch = argStr.charAt(cIdx);
	    statements.add("6");
	    if (ch != ' ' || last != ' ') {
		statements.add("7");
		argBuf.append(ch);
		statements.add("8");
		last = ch;
	    }
	    statements.add("9");
	    cIdx++;
	}
	statements.add("10");
	return argBuf.toString();
    }
    public static String collapseSpacesCorr(String argStr)
    {
	char last = argStr.length() > 0? argStr.charAt(0) : ' ';
	StringBuffer argBuf = new StringBuffer();
	for (int cIdx = 0 ; cIdx < argStr.length(); cIdx++) {
	    char ch = argStr.charAt(cIdx);
	    if (ch != ' ' || last != ' ') {
		argBuf.append(ch);
		last = ch;
	    }
	}
	return argBuf.toString();
    }
    public static String collapseSpacesCorrInstr(String argStr)
    {
	statements.add("1");
	char last = argStr.length() > 0? argStr.charAt(0) : ' ';
	statements.add("2");
	StringBuffer argBuf = new StringBuffer();
	statements.add("3");
	int cIdx = 0;
	statements.add("4");
	while (cIdx < argStr.length()) {
	    statements.add("5");
	    char ch = argStr.charAt(cIdx);
	    statements.add("6");
	    if (ch != ' ' || last != ' ') {
		statements.add("7");
		argBuf.append(ch);
		statements.add("8");
		last = ch;
	    }
	    statements.add("9");
	    cIdx++;
	}
	statements.add("10");
	return argBuf.toString();
    }
    static java.util.Set<String> mcdc = new java.util.HashSet<String>();
    static private boolean evalBool(boolean b, String s) {
	mcdc.add(s + (b? "T" : "F"));
	return b;
    }
    public static String collapseSpacesCorrInstrMCDC(String argStr)
    {
	char last = argStr.length() > 0? argStr.charAt(0) : ' ';
	StringBuffer argBuf = new StringBuffer();
	int cIdx = 0;
	while (evalBool(cIdx < argStr.length(), "1")) {
	    char ch = argStr.charAt(cIdx);
	    if (evalBool(ch != ' ', "2") || evalBool(last != ' ', "3")) {
		argBuf.append(ch);
		last = ch;
	    }
	    cIdx++;
	}
	return argBuf.toString();
    }
    public static void main(String[] args) throws Exception
    {
	java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(args[0]));
        String st;
        while ((st = br.readLine()) != null) {
	    System.out.println(collapseSpacesCorr(st));
	    collapseSpacesCorrInstr(st);
	    collapseSpacesCorrInstrMCDC(st);
	    // System.out.println(collapseSpaces(st));
	    // collapseSpacesInstr(st);
	}
	System.out.println(100.0*statements.size()/10.0);
	// A B [A or B]
	// 0 0 0 this	
	// 0 1 1 this
	// 1 0 1 this
	// 1 1 1
	int cnt1 = 0, cnt2 = 0;
	if (mcdc.contains("1T"))
	    cnt1++;
	if (mcdc.contains("1F"))
	    cnt1++;
	if (mcdc.contains("2F") && mcdc.contains("3T"))
	    cnt2++;
	if (mcdc.contains("2T") && mcdc.contains("3F"))
	    cnt2++;
	if (mcdc.contains("2F") && mcdc.contains("3F"))
	    cnt2++;
	System.out.println(100*cnt1/2.0);
	System.out.println(100*cnt2/3.0);
    }
}
