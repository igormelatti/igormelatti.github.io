import sys

def read_input(filename):
    f = open(filename, "r")
    content = f.readlines()
    f.close()
    V = set()
    gen = {}
    use = {}
    kill = {}
    pred = {}
    succ = {}
    for l in content:
        first_split = l.split("|")
        line = first_split[0]
        linear = line.split()
        if linear == []:
            continue
        if linear[0] == "nodes":
            V.add(linear[1])
            if len(linear) > 2:
                gen[linear[1]] = set()
                for v in linear[2:]:
                    gen[linear[1]].add((v, linear[1]))
            if len(first_split) == 2:
                uses = first_split[1].split()
                use[linear[1]] = set()
                for v in uses:
                    use[linear[1]].add(v)
        else:
            for i in [1, 2]:
                if linear[i] not in V:
                    print("%s not in previous nodes section" %linear[i])
                    sys.exit(1)
            if linear[1] in succ:
                succ[linear[1]] += [linear[2]]
            else:
                succ[linear[1]] = [linear[2]]
            if linear[2] in pred:
                pred[linear[2]] += [linear[1]]
            else:
                pred[linear[2]] = [linear[1]]
    all_vars = set()
    for n in V:
        if n in gen:
            all_vars = all_vars.union(gen[n])
        else:
            gen[n] = set()
    for n in gen:
        kill[n] = set()
        for (v, _) in gen[n]:
            for m in gen:
                if n == m:
                    continue
                for (w, _) in gen[m]:
                    if v != w:
                        continue
                    kill[n].add((w, m))
    return (V, pred, succ, gen, use, kill, all_vars)

def main_comp(V, pred, succ, gen, kill, all_vars):
    reach = {}
    reach_out = {}
    for n in V:
        reach_out[n] = set()
    work_list = V
    while len(work_list) != 0:
        n = work_list.pop()
        old_val = reach_out[n]
        reach[n] = set()
        if n in pred:
            for m in pred[n]:
                reach[n] = reach[n].union(reach_out[m])
        reach_out[n] = reach[n].difference(kill[n]).union(gen[n])
        if old_val != reach_out[n]:
            work_list = work_list.union(succ[n] if n in succ else set())
        # print(n, reach[n], reach_out[n], work_list)
    return reach

def main(filename):
    V, pred, succ, gen, use, kill, all_vars = read_input(filename)
    print("V: " + str(V))
    print("pred: " + str(pred))
    print("succ: " + str(succ))
    print("gen: " + str(gen))
    print("use: " + str(use))
    print("kill: " + str(kill))
    print("all_vars: " + str(all_vars))
    reach = main_comp(V, pred, succ, gen, kill, all_vars)
    vars_res = {}
    for n in reach:
        print("res: " + str(n) + "->" + str(reach[n]))
        for (i, j) in reach[n]:
            if i in use[n]:
                if not(i in vars_res):
                    vars_res[i] = set()
                vars_res[i].add((j, n))
    print("Thus we have the following pairs:")
    for v in vars_res:
        print("%s --> %s" %(v, str(vars_res[v])))

main(sys.argv[1])
