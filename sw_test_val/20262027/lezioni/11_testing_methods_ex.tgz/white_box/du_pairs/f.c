char *Hex_Values;

int cgi_decode(char *encoded, char *decoded) {
  char *eptr = encoded;
  char *dptr = decoded;
  int ok=0;
  while (*eptr) {
    char c;
    c = *eptr;
    if (c == '+' ) { /* Case 1: '+' maps to blank */
      *dptr = ' ' ;
    } else if (c == '%' ) { /* Case 2: '%xx' is hex for character xx */
      int digit_high = Hex_Values[*(++eptr)];
      int digit_low = Hex_Values[*(++eptr)];
      if (
	  digit_high == -1 || digit_low == -1 ) {
	/* *dptr='?'; */
	ok=1; /* Bad return code */
      } else {
	*dptr = 16* digit_high + digit_low;
      }
    } else { /* Case 3: All other characters map to themselves */
      *dptr = *eptr;
    }
    ++dptr;
    ++eptr;
  }
  *dptr = '\0' ;
  return ok;
}
