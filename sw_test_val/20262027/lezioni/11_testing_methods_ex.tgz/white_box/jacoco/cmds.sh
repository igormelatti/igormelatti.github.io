rm -rf input*txt.res
for f in input*txt
do
    mkdir -p $f.res
    java -javaagent:./jacocoagent.jar collapse_spaces $f
    mv jacoco.exec $f.res/jacoco.exec
    mkdir -p $f.res/html_out
    java -jar jacococli.jar report $f.res/jacoco.exec --classfiles ./collapse_spaces.class --csv $f.res/output.csv --html $f.res/html_out --sourcefiles ./collapse_spaces.java --xml $f.res/xml_out
done
