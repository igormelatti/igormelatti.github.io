class collapse_spaces {
    /**
     * Remove/collapse multiple spaces.
     *
     * @param String string to remove multiple spaces from.
     * @return String
     */
    // public static String collapseSpaces(String argStr)
    // {
    // 	char last = argStr.charAt(0);
    // 	StringBuffer argBuf = new StringBuffer();
    // 	for (int cIdx = 0 ; cIdx < argStr.length(); cIdx++) {
    // 	    char ch = argStr.charAt(cIdx);
    // 	    if (ch != ' ' || last != ' ') {
    // 		argBuf.append(ch);
    // 		last = ch;
    // 	    }
    // 	}
    // 	return argBuf.toString();
    // }
    public static String collapseSpacesCorr(String argStr)
    {
	char last = argStr.length() > 0? argStr.charAt(0) : ' ';
	StringBuffer argBuf = new StringBuffer();
	for (int cIdx = 0 ; cIdx < argStr.length(); cIdx++) {
	    char ch = argStr.charAt(cIdx);
	    if (ch != ' ' || last != ' ') {
		argBuf.append(ch);
		last = ch;
	    }
	}
	return argBuf.toString();
    }
    public static String collapseSpacesCorr2(String argStr)
    {
	char last;
	if (argStr.length() > 0)
	    last = argStr.charAt(0);
	else
	    last = ' ';
	StringBuffer argBuf = new StringBuffer();
	for (int cIdx = 0 ; cIdx < argStr.length(); cIdx++) {
	    char ch = argStr.charAt(cIdx);
	    if (ch != ' ' || last != ' ') {
		argBuf.append(ch);
		last = ch;
	    }
	}
	return argBuf.toString();
    }
    public static void main(String[] args) throws Exception
    {
	java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(args[0]));
        String st;
        while ((st = br.readLine()) != null) {
	    System.out.println(collapseSpacesCorr(st));
	    System.out.println(collapseSpacesCorr2(st));
	}
    }
}
