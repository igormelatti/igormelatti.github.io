def decision(c):
    return (((c[0] or c[1]) and c[2]) or c[3]) and c[4]

cases = [[True, False, True, False, True], [False, True, True, False, True], [True, False, False, True, True], [False, True, False, True, True], [False, False, False, True, True], [True, False, True, False, False], [False, True, True, False, False], [True, False, False, True, False], [False, True, False, True, False], [False, False, False, True, False], [True, False, False, False, False], [False, True, False, False, False], [False, False, False, False, False]]
for c in cases:
    print(c, decision(c))
